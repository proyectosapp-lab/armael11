/* ══════════════════════════════════════════════════════════════════════════
   MEDIDO-NBA — arma la pantalla "Está medido": la tabla de calibración
   ("cuando dice 70%, pasa el 69%") sobre las temporadas de TRABAJO que hay
   en datos/, y los números de la prueba limpia tal como quedaron escritos
   el 22/9/2026 (medidas/prueba-limpia.md y claude/nba-fase1.md). No toca
   datos-limpios/: la limpia se corrió una sola vez y no se repite.

     node medido-nba.mjs        → docs/datos/nba-medido.json y .js
   ══════════════════════════════════════════════════════════════════════════ */
import { writeFileSync, mkdirSync } from "node:fs";
import { caminar, calibracion, medir, cargar } from "./backtest-nba.mjs";
const aca = p => new URL(p, import.meta.url);

/* Lo que dio la prueba limpia (2023-24 y 2024-25, 2.151 partidos, una sola
   corrida). Se copia a mano: es un resultado, no se recalcula. */
export const LIMPIA = {
  temporadas: "2023-24 y 2024-25", partidos: 2151,
  acierta: { m0: 0.657, m1: 0.676, m1d: 0.681, mejorRecord: 0.655 },
  brier: { h1: { ventaja: 0.0038, t: 2.9 }, h2: { ventaja: 0.0089, t: 4.5, n: 1343 } },
  margen: { h5: { ecm: 13.9, ecmSin: 14.2, t: 3.8 }, b2b: { puntos: 2.91, t: 4.8 } },
};

export function armarMedido(temporadas) {
  const filas = caminar(temporadas).filter(f => f.m0 && f.m0.evaluable !== false && f.m1d);
  const cajas = calibracion(filas, "m1d").filter(c => c.n >= 30);
  const r = medir(filas, "m1d", "vara");
  return {
    generado: new Date().toISOString(),
    trabajo: { temporadas: temporadas.map(t => t.temporada), partidos: filas.length, acierta: +r.acierta.toFixed(3),
      calibracion: cajas.map(c => ({ dice: +c.pMedia.toFixed(2), pasa: +c.real.toFixed(2), n: c.n })) },
    limpia: LIMPIA,
  };
}

if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split(/[\\/]/).pop())) {
  const T = cargar(["./datos/"]).sort((a, b) => a.temporada - b.temporada);
  const m = armarMedido(T);
  mkdirSync(aca("./docs/datos/"), { recursive: true });
  writeFileSync(aca("./docs/datos/nba-medido.json"), JSON.stringify(m));
  writeFileSync(aca("./docs/datos/nba-medido.js"), "window.NBA_MEDIDO=" + JSON.stringify(m) + ";\n");
  console.log(`  trabajo: ${m.trabajo.partidos} partidos, acierta ${(m.trabajo.acierta * 100).toFixed(1)}%`);
  for (const c of m.trabajo.calibracion) console.log(`    dice ${(c.dice * 100).toFixed(0)}% → pasa ${(c.pasa * 100).toFixed(0)}%  (${c.n})`);
}
