/* ══════════════════════════════════════════════════════════════════════════
   REDES — el kit de Instagram de Armá el Quinteto. Lee lo que dejó el motor
   (docs/datos/nba-hoy.json, nba-medido.json) y arma las imágenes y los
   textos del día en redes/hoy/:

     baja.png (1080×1350, feed)  · baja-historia.png (1080×1920)
     partidos.png (1080×1350)    · textos.md (los pies de foto, para copiar)

   Y con --lanzamiento, los tres primeros posteos en redes/lanzamiento/.

   Todo lo que arma es puro (SVG como texto); sharp solo convierte a PNG.
   Las fuentes van en marca/fuentes/ para que el runner de GitHub las tenga.
     node redes.mjs                 (el día)
     node redes.mjs --lanzamiento   (los tres primeros)
   ══════════════════════════════════════════════════════════════════════════ */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { createRequire } from "node:module";
const aca = p => new URL(p, import.meta.url);

export const COLOR = { naranja: "#E8731C", naranjaNoche: "#F7A45A", papel: "#F6F1EA", tinta: "#14110F", noche: "#0D1117", gris: "#9AA4B2", tenue: "#5C6675", local: "#2A5FA8", visita: "#8A2E2E", ok: "#67D38A", blanco: "#FFFFFF" };
const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const pct = p => Math.round(p * 100) + "%";
const num = (x, d = 1) => x.toLocaleString("es-AR", { minimumFractionDigits: d, maximumFractionDigits: d });
const hora = iso => new Intl.DateTimeFormat("es-AR", { timeZone: "America/Argentina/Buenos_Aires", hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(iso));
const apellido = n => n.split(" ").slice(-1)[0];
const MOTIVOS = [[/Injury\/Illness - /i, ""], [/Left /i, "izq. "], [/Right /i, "der. "], [/Knee/i, "rodilla"], [/Ankle/i, "tobillo"], [/Hamstring/i, "isquiotibial"], [/Calf/i, "pantorrilla"], [/Back/i, "espalda"], [/Shoulder/i, "hombro"], [/Wrist/i, "muñeca"], [/Hand/i, "mano"], [/Foot/i, "pie"], [/Hip/i, "cadera"], [/Illness/i, "enfermedad"], [/Soreness/i, "molestia"], [/Sprain/i, "esguince"], [/Strain/i, "desgarro"], [/Contusion/i, "golpe"], [/Rest/i, "descanso"], [/Injury Management/i, "manejo de la lesión"], [/Return to Competition Reconditioning/i, "puesta a punto"], [/Personal/i, "motivo personal"], [/Surgery/i, "cirugía"], [/Fracture/i, "fractura"], [/Concussion Protocol/i, "protocolo de conmoción"]];
export function motivoEs(m) { if (!m) return ""; for (const [r, t] of MOTIVOS) m = m.replace(r, t); return m.replace(/;/g, ",").trim(); }
export const ESTADO = { Out: "no juega", Doubtful: "casi seguro no juega", Questionable: "en duda", Probable: "probable" };

/* ── piezas ── */
function pelota(cx, cy, r, costura = COLOR.tinta) {
  const g = r * 0.085, k = r * 0.62;
  return `<g><circle cx="${cx}" cy="${cy}" r="${r}" fill="${COLOR.naranja}"/><g fill="none" stroke="${costura}" stroke-width="${g}" stroke-linecap="round"><line x1="${cx}" y1="${cy - r}" x2="${cx}" y2="${cy + r}"/><line x1="${cx - r}" y1="${cy}" x2="${cx + r}" y2="${cy}"/><path d="M ${cx - k} ${cy - r * 0.78} Q ${cx - r * 0.05} ${cy} ${cx - k} ${cy + r * 0.78}"/><path d="M ${cx + k} ${cy - r * 0.78} Q ${cx + r * 0.05} ${cy} ${cx + k} ${cy + r * 0.78}"/></g><circle cx="${cx}" cy="${cy}" r="${r - g / 2}" fill="none" stroke="${costura}" stroke-width="${g}"/></g>`;
}
function marca(x, y, alto = 64, tinta = COLOR.blanco, nar = COLOR.naranjaNoche) {
  return `<g transform="translate(${x} ${y})"><rect width="${alto}" height="${alto}" rx="${alto * 0.24}" fill="#fff"/>${pelota(alto / 2, alto / 2, alto * 0.33)}
  <text x="${alto + 20}" y="${alto * 0.68}" font-size="${alto * 0.5}" font-weight="700" fill="${tinta}">Armá el <tspan fill="${nar}">Quinteto</tspan></text></g>`;
}
function pie(w, h, texto = "app independiente · sin cuotas · armaelquinteto.com") {
  return `<text x="${w / 2}" y="${h - 60}" text-anchor="middle" font-size="30" font-weight="500" fill="${COLOR.tenue}">${esc(texto)}</text>`;
}
/* parte una frase en renglones de hasta `max` letras, sin cortar palabras */
export function renglones(texto, max) {
  const out = []; let l = "";
  for (const w of texto.split(" ")) { if ((l + " " + w).trim().length > max && l) { out.push(l); l = w; } else l = (l + " " + w).trim(); }
  if (l) out.push(l); return out;
}
const lienzo = (w, h, cuerpo, fondo = COLOR.noche) => `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" font-family="Poppins, sans-serif"><rect width="${w}" height="${h}" fill="${fondo}"/>${cuerpo}</svg>`;

/* ── la baja de la noche ── */
export function fraseBaja(b) { return `Sin ${apellido(b.jugador)}, ${b.equipo} pasa de ${pct(b.pCon)} a ${pct(b.pSin)}`; }
export function imagenBaja(b, formato = "feed") {
  const w = 1080, h = formato === "historia" ? 1920 : 1350, top = formato === "historia" ? 380 : 200;
  const frase = renglones(fraseBaja(b), 20);
  const tam = frase.length > 2 ? 78 : 92;
  let y = top + 90;
  const lineas = frase.map((r, i) => `<text x="80" y="${y + i * tam * 1.15}" font-size="${tam}" font-weight="700" fill="${COLOR.blanco}">${esc(r).replace(new RegExp(esc(apellido(b.jugador))), `<tspan fill="${COLOR.naranjaNoche}">${esc(apellido(b.jugador))}</tspan>`).replace(/(\d+%)/g, `<tspan fill="${COLOR.naranjaNoche}">$1</tspan>`)}</text>`).join("");
  y += frase.length * tam * 1.15 + 30;
  const det = [`${ESTADO[b.estado] || "no juega"}${b.motivo ? " · " + esc(motivoEs(b.motivo)) : ""}`, `${b.local ? "recibe a" : "visita a"} ${b.rival} · ${hora(b.fecha)} hora argentina`, `${num(-b.peso, 1)} puntos de margen sin él`];
  const detalle = det.map((t, i) => `<text x="80" y="${y + 20 + i * 50}" font-size="34" font-weight="500" fill="${COLOR.gris}">${t}</text>`).join("");
  const cuerpo = marca(80, 80) + `<text x="80" y="${top}" font-size="30" font-weight="700" fill="${COLOR.naranjaNoche}" letter-spacing="4">LA BAJA DE LA NOCHE</text>` + lineas + detalle +
    `<g opacity="0.08">${pelota(w - 120, h - 260, 320, COLOR.blanco)}</g>` + pie(w, h);
  return lienzo(w, h, cuerpo);
}

/* ── los partidos del día ── */
export function imagenPartidos(partidos, fecha) {
  const w = 1080, h = 1350;
  const lista = [...partidos].sort((a, b) => new Date(a.fecha) - new Date(b.fecha)).slice(0, 12);
  const alto = Math.min(84, Math.floor(900 / Math.max(lista.length, 1)));
  const filas = lista.map((p, i) => {
    const y = 300 + i * alto, pl = p.m1d.p, pv = 1 - pl, fav = pl >= 0.5 ? p.local : p.visita;
    const anchoBarra = 380, x0 = 520;
    return `<text x="80" y="${y + alto * 0.62}" font-size="${Math.min(36, alto * 0.42)}" font-weight="700" fill="${COLOR.blanco}">${esc(p.visita.codigo)} <tspan fill="${COLOR.tenue}" font-weight="500">@</tspan> ${esc(p.local.codigo)}</text>
      <text x="330" y="${y + alto * 0.62}" font-size="${Math.min(30, alto * 0.36)}" font-weight="500" fill="${COLOR.gris}">${hora(p.fecha)}</text>
      <rect x="${x0}" y="${y + alto * 0.2}" width="${anchoBarra}" height="${alto * 0.5}" rx="10" fill="#2A313D"/>
      <rect x="${x0}" y="${y + alto * 0.2}" width="${anchoBarra * pv}" height="${alto * 0.5}" rx="10" fill="${COLOR.visita}"/>
      <rect x="${x0 + anchoBarra * pv}" y="${y + alto * 0.2}" width="${anchoBarra * pl}" height="${alto * 0.5}" rx="10" fill="${COLOR.local}"/>
      <text x="${x0 + anchoBarra + 20}" y="${y + alto * 0.62}" font-size="${Math.min(34, alto * 0.4)}" font-weight="700" fill="${COLOR.naranjaNoche}">${esc(fav.codigo)} ${pct(Math.max(pl, pv))}</text>`;
  }).join("");
  const cuerpo = marca(80, 80) + `<text x="80" y="220" font-size="30" font-weight="700" fill="${COLOR.naranjaNoche}" letter-spacing="4">LOS PARTIDOS DE ${esc((fecha || "HOY").toUpperCase())}</text>` + filas +
    `<text x="80" y="${h - 130}" font-size="26" font-weight="500" fill="${COLOR.tenue}">con el parte de lesionados oficial aplicado · hora argentina</text>` + pie(w, h);
  return lienzo(w, h, cuerpo);
}

/* ── los del lanzamiento ── */
export function imagenPresentacion() {
  const w = 1080, h = 1350;
  const cuerpo = `<g transform="translate(340 200)"><rect width="400" height="400" rx="92" fill="#fff"/>${pelota(200, 200, 125)}</g>
    <text x="${w / 2}" y="760" text-anchor="middle" font-size="86" font-weight="700" fill="${COLOR.blanco}">Armá el</text>
    <text x="${w / 2}" y="870" text-anchor="middle" font-size="104" font-weight="700" fill="${COLOR.naranjaNoche}">Quinteto</text>
    <text x="${w / 2}" y="990" text-anchor="middle" font-size="38" font-weight="500" fill="${COLOR.gris}">Sacá un jugador.</text>
    <text x="${w / 2}" y="1045" text-anchor="middle" font-size="38" font-weight="500" fill="${COLOR.gris}">Mirá cuánto se mueve el partido.</text>` + pie(w, h);
  return lienzo(w, h, cuerpo);
}
export function imagenMedido(m) {
  const w = 1080, h = 1350;
  const cal = (m.trabajo.calibracion || []).filter(c => c.n >= 300);
  const filas = cal.map((c, i) => { const y = 560 + i * 78; return `<text x="200" y="${y}" font-size="40" font-weight="500" fill="${COLOR.gris}">dice ${pct(c.dice)}</text><text x="560" y="${y}" font-size="40" font-weight="700" fill="${COLOR.naranjaNoche}">pasa ${pct(c.pasa)}</text>`; }).join("");
  const cuerpo = marca(80, 80) + `<text x="80" y="220" font-size="30" font-weight="700" fill="${COLOR.naranjaNoche}" letter-spacing="4">ESTÁ MEDIDO</text>
    <text x="80" y="330" font-size="72" font-weight="700" fill="${COLOR.blanco}">Cuando dice 70%,</text><text x="80" y="420" font-size="72" font-weight="700" fill="${COLOR.blanco}">pasa el <tspan fill="${COLOR.naranjaNoche}">69%</tspan>.</text>` + filas +
    `<text x="80" y="${h - 200}" font-size="30" font-weight="500" fill="${COLOR.gris}">${num(m.trabajo.partidos, 0)} partidos de 2016 a 2023. Probado una sola vez sobre</text><text x="80" y="${h - 155}" font-size="30" font-weight="500" fill="${COLOR.gris}">${num(m.limpia.partidos, 0)} que nunca había visto: acierta el ganador el ${pct(m.limpia.acierta.m1d)}.</text>` + pie(w, h);
  return lienzo(w, h, cuerpo);
}

/* ── los textos ── */
export function textoBaja(b) {
  return `${fraseBaja(b)}.\n\n${b.jugador} ${ESTADO[b.estado] || "no juega"}${b.motivo ? " (" + motivoEs(b.motivo) + ")" : ""}. ${b.equipo} ${b.local ? "recibe a" : "visita a"} ${b.rival} a las ${hora(b.fecha)}. Son ${num(b.peso, 1)} puntos de margen: sus minutos habituales por lo que produce por minuto, menos lo que produce el que entra por él.\n\nEn la app podés sacarlo y ponerlo, y ver cuánto se mueve. Link en la bio.\n\nApp independiente. Sin cuotas.\n#NBA #${b.codigo} #ArmáElQuinteto`;
}
export function textoPartidos(partidos, baja) {
  const lista = [...partidos].sort((a, b) => new Date(a.fecha) - new Date(b.fecha)).map(p => { const fav = p.m1d.p >= 0.5 ? p.local : p.visita; return `${p.visita.codigo} @ ${p.local.codigo} · ${hora(p.fecha)} · ${fav.apodo} ${pct(Math.max(p.m1d.p, 1 - p.m1d.p))}`; });
  return `Los partidos de hoy, con el parte de lesionados aplicado:\n\n${lista.join("\n")}\n\n${baja ? "La baja que más pesa: " + baja.jugador + " (" + baja.codigo + "), " + num(-baja.peso, 1) + " puntos.\n\n" : ""}Hora argentina. Sacá o poné jugadores en la app: link en la bio.\n\nApp independiente. Sin cuotas.\n#NBA #ArmáElQuinteto`;
}

/* ── a PNG ── */
function cargarSharp() {
  const req = createRequire(import.meta.url);
  for (const c of [process.env.SHARP, "sharp", "/home/claude/.npm-global/lib/node_modules/sharp"].filter(Boolean)) { try { return req(c); } catch (e) {} }
  throw new Error("Falta sharp: npm i sharp (o SHARP=<ruta>)");
}
/* fontconfig apunta a marca/fuentes/, así el runner de GitHub tiene Poppins */
function prepararFuentes() {
  const dir = aca("./marca/fuentes/").pathname;
  const conf = aca("./marca/fuentes/fonts.conf").pathname;
  writeFileSync(conf, `<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>${dir}</dir><cachedir>/tmp/fc-quinteto</cachedir><config></config></fontconfig>`);
  if (!process.env.FONTCONFIG_FILE) process.env.FONTCONFIG_FILE = conf;
}
export async function aPng(svg, ruta) { const sharp = cargarSharp(); await sharp(Buffer.from(svg), { density: 96 }).png().toFile(ruta); }

async function main() {
  prepararFuentes();
  if (process.argv.includes("--lanzamiento")) {
    const d = aca("./redes/lanzamiento/").pathname; mkdirSync(d, { recursive: true });
    const medido = JSON.parse(readFileSync(aca("./docs/datos/nba-medido.json"), "utf8"));
    const hoy = JSON.parse(readFileSync(aca("./docs/datos/nba-hoy.json"), "utf8"));
    await aPng(imagenPresentacion(), d + "1-presentacion.png");
    await aPng(imagenMedido(medido), d + "2-esta-medido.png");
    if (hoy.baja) await aPng(imagenBaja(hoy.baja), d + "3-la-baja.png");
    console.log("lanzamiento armado en redes/lanzamiento/"); return;
  }
  const hoy = JSON.parse(readFileSync(aca("./docs/datos/nba-hoy.json"), "utf8"));
  const d = aca("./redes/hoy/").pathname; mkdirSync(d, { recursive: true });
  const diaArg = iso => new Intl.DateTimeFormat("en-CA", { timeZone: "America/Argentina/Buenos_Aires", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(iso));
  const todos = [...(hoy.partidos || [])].sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
  /* solo el primer día (hora argentina): el posteo es de hoy, no de 48 h */
  const partidos = todos.filter(p => diaArg(p.fecha) === diaArg(todos[0].fecha));
  if (!partidos.length) { writeFileSync(d + "textos.md", "# Hoy\n\nNo hay partidos en las próximas 48 horas.\n"); console.log("  sin partidos: nada que postear"); return; }
  const fecha = new Intl.DateTimeFormat("es-AR", { timeZone: "America/Argentina/Buenos_Aires", weekday: "long", day: "numeric" }).format(new Date(partidos[0].fecha));
  await aPng(imagenPartidos(partidos, fecha), d + "partidos.png");
  let md = `# Instagram · ${fecha}\n\n## Los partidos (partidos.png)\n\n${textoPartidos(partidos, hoy.baja)}\n`;
  if (hoy.baja) { await aPng(imagenBaja(hoy.baja), d + "baja.png"); await aPng(imagenBaja(hoy.baja, "historia"), d + "baja-historia.png"); md += `\n## La baja de la noche (baja.png · baja-historia.png)\n\n${textoBaja(hoy.baja)}\n`; }
  else md += "\n## La baja de la noche\n\nHoy no hay una baja que pese. No se postea.\n";
  writeFileSync(d + "textos.md", md);
  console.log(`  redes/hoy/: partidos.png${hoy.baja ? ", baja.png, baja-historia.png" : ""}, textos.md`);
}
if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split(/[\\/]/).pop())) await main();
