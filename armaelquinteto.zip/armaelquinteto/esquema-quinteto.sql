-- ══════════════════════════════════════════════════════════════════════════
-- ESQUEMA-QUINTETO — la cuenta, el pase y la prueba gratis de Armá el
-- Quinteto en el MISMO Supabase de Armá el 11 y Sacá vos. Pegar en el
-- editor SQL, después de esquema.sql y de esquema-sacavos.sql. Idempotente:
-- se puede pegar dos veces.
--
-- Reusa las tablas `pase (perfil, producto, hasta)` y `prueba (perfil,
-- producto, desde, hasta)` de Sacá vos, con el producto 'quinteto'. Si por
-- algún motivo no existen todavía, las crea con la misma forma.
--
-- Lo que NO hace, y hay que hacer a mano (ver el final):
--   1. registrar_pago: que el plan 'quinteto' acredite en `pase`, como
--      hace 'sacavos'.
--   2. crear-pago (Edge Function): el plan 'quinteto' con su precio.
-- Sin (1), un pago de Armá el Quinteto haría saltar poner_plan y Mercado
-- Pago reintentaría por días. Por eso el cobro arranca APAGADO.
-- ══════════════════════════════════════════════════════════════════════════

-- ── las tablas (si no las dejó Sacá vos) ──────────────────────────────────
create table if not exists public.pase (
  perfil    uuid not null references public.perfil(id) on delete cascade,
  producto  text not null,
  hasta     timestamptz not null,
  primary key (perfil, producto)
);
alter table public.pase enable row level security;
drop policy if exists "pase: leer el propio" on public.pase;
create policy "pase: leer el propio" on public.pase for select using (auth.uid() = perfil);
-- sin políticas de insert/update/delete: desde el teléfono no se escribe

create table if not exists public.prueba (
  perfil    uuid not null references public.perfil(id) on delete cascade,
  producto  text not null,
  desde     timestamptz not null default now(),
  hasta     timestamptz not null,
  primary key (perfil, producto)
);
alter table public.prueba enable row level security;
drop policy if exists "prueba: leer la propia" on public.prueba;
create policy "prueba: leer la propia" on public.prueba for select using (auth.uid() = perfil);

-- ── los ajustes: el cobro arranca apagado ─────────────────────────────────
create table if not exists public.ajuste (
  clave    text primary key,
  valor    text not null,
  cambiado timestamptz not null default now()
);
alter table public.ajuste enable row level security;
drop policy if exists "ajuste: leer todos" on public.ajuste;
create policy "ajuste: leer todos" on public.ajuste for select using (true);
insert into public.ajuste (clave, valor) values ('cobra_quinteto', 'no') on conflict (clave) do nothing;
insert into public.ajuste (clave, valor) values ('prueba_quinteto_dias', '3') on conflict (clave) do nothing;

-- ── la prueba gratis, por cuenta ──────────────────────────────────────────
-- La primera vez que la persona entra con su cuenta, la empieza; después
-- la devuelve igual. No se alarga ni se reinicia borrando el navegador o
-- cambiando de teléfono, porque vive en la base y no en el teléfono.
create or replace function public.mi_prueba_quinteto()
returns table (desde timestamptz, hasta timestamptz)
language plpgsql security definer set search_path = public as $$
declare
  dias int := coalesce((select valor::int from public.ajuste where clave = 'prueba_quinteto_dias'), 3);
begin
  if auth.uid() is null then return; end if;
  insert into public.prueba (perfil, producto, desde, hasta)
    values (auth.uid(), 'quinteto', now(), now() + make_interval(days => dias))
    on conflict (perfil, producto) do nothing;
  return query select p.desde, p.hasta from public.prueba p where p.perfil = auth.uid() and p.producto = 'quinteto';
end $$;
revoke all on function public.mi_prueba_quinteto() from public;
grant execute on function public.mi_prueba_quinteto() to authenticated;

-- ── acreditar el pase (la llama registrar_pago; suma sobre lo que quedaba) ─
create or replace function public.acreditar_pase_quinteto(p_perfil uuid, p_meses int)
returns timestamptz language plpgsql security definer set search_path = public as $$
declare nuevo timestamptz;
begin
  insert into public.pase (perfil, producto, hasta)
    values (p_perfil, 'quinteto', now() + make_interval(months => greatest(p_meses, 1)))
    on conflict (perfil, producto) do update
      set hasta = greatest(public.pase.hasta, now()) + make_interval(months => greatest(p_meses, 1))
    returning hasta into nuevo;
  return nuevo;
end $$;
revoke all on function public.acreditar_pase_quinteto(uuid, int) from public;

-- ══════════════════════════════════════════════════════════════════════════
-- A MANO, ANTES DE PRENDER EL COBRO
--
-- 1. En `registrar_pago` (la versión de esquema-sacavos.sql), donde dice
--        if plan = 'sacavos' then perform acreditar_pase(...)
--    agregar la rama
--        elsif plan = 'quinteto' then perform acreditar_pase_quinteto(perfil, meses);
--    Mismo lugar en `pago-play` y `pago-apple` cuando lleguen las tiendas.
--
-- 2. En la Edge Function `crear-pago`, en la tabla PLANES, agregar
--        quinteto: { precio: <precio>, meses: 1, titulo: "Armá el Quinteto · un mes",
--                    vuelta: "https://armaelquinteto.com/gracias.html", resumen: "QUINTETO" }
--    Es el único lugar del proyecto con el precio. Y que el GET de la
--    función devuelva el plan pedido (?plan=quinteto) para que la app lo
--    dibuje.
--
-- 3. Recién entonces:
--        update public.ajuste set valor = 'si', cambiado = now() where clave = 'cobra_quinteto';
--    Se apaga con 'no'. Hasta entonces la app muestra todo a todos.
-- ══════════════════════════════════════════════════════════════════════════
