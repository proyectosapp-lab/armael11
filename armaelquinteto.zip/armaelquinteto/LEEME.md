# Armá el Quinteto — marca, app, redes y cuentas (29/9/2026)

Qué va dónde en el repo `starting5`:

| carpeta del zip | a dónde | qué es |
|---|---|---|
| `docs/` | `docs/` (reemplaza todo) | la app: index.html, quinteto.css, quinteto.js, quinteto-cuentas.js, sitio.js, gracias, privacidad, íconos, manifest, datos de muestra |
| raíz `*.mjs`, `*.sql` | raíz | motor con registro/jugados/la baja, medido, redes, pruebas, SQL |
| `workflows/nba-diario.yml` | `.github/workflows/nba-diario.yml` (con el lápiz) | el diario con pruebas nuevas, medido y las imágenes |
| `marca/` | `marca/` | logos, íconos, fuentes (las necesita redes.mjs en el runner), identidad.md |
| `redes/` | `redes/` | instagram.md, los tres posteos del lanzamiento, el ejemplo del día |

Después de subir: correr "NBA diario" a mano. Con la temporada sin
empezar va a decir "no hay partidos"; los datos de muestra de `docs/datos/`
(marzo de 2023 replayado, con un parte inventado para que se vea la baja)
quedan hasta que el motor los pise en octubre.

**Cuentas y cobro.** `docs/sitio.js` tiene las dos claves públicas de
Supabase vacías: copiarlas del `docs/sitio.js` de Sacá vos. Con las claves
vacías la app corre abierta. `esquema-quinteto.sql` se pega en Supabase
(probado en Postgres local, dos veces); el cobro arranca apagado y el SQL
dice al final qué falta tocar a mano en `registrar_pago` y `crear-pago`
(necesito esos dos archivos para dejarlos listos).
