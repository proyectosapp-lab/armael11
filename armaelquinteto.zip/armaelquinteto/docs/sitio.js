/* SITIO.JS — la configuración pública de Armá el Quinteto. Las dos claves
   de Supabase son las MISMAS de Armá el 11 y Sacá vos (copiarlas del
   docs/sitio.js de Sacá vos): son públicas, viajan al navegador igual.
   Con las dos vacías la app corre abierta, sin cuenta ni cobro. */
window.Q5_SITIO = {
  supabaseUrl: "",
  supabaseAnon: "",
  vuelta: "https://armaelquinteto.com/gracias.html",
};
