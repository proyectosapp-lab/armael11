/* ══════════════════════════════════════════════════════════════════════════
   QUINTETO.JS — la app de Armá el Quinteto. Lee lo que deja el motor dos
   veces por día (window.NBA_HOY, NBA_JUGADOS, NBA_MEDIDO) y arma las
   cuatro pantallas: Hoy (la puerta es un partido ya cargado, con la
   rotación), Jugados, Está medido y Ajustes (con la cuenta).

   Script clásico, ámbito global compartido: todo lo de acá empieza con q5.

   ── LA REGLA DE PRESENTACIÓN DE LOS PESOS (22/9/2026) ────────────────────
   Un peso entre −1 y +0,5 se muestra como "≈ 0" y cuenta 0 acá. Vale igual
   para todos. No cambia el pronóstico que publica el motor: cambia lo que
   la pantalla suma cuando la persona toca. La cuenta es la que se ve:
   margen = base ± los pesos de los que no juegan.

   ── EL ACCESO ────────────────────────────────────────────────────────────
   Gratis: la baja de la noche, quién juega y cuándo, los jugados y "Está
   medido". Con el pase (o en la prueba gratis): el número de cada partido
   y la rotación. Lo decide el servidor (quinteto-cuentas.js); acá solo se
   dibuja el candado. El botón del pase se ve siempre que haya cobro.
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
  "use strict";
  var Q5_BANDA = { desde: -1, hasta: 0.5 };
  var Q5_HORARIA = "America/Argentina/Buenos_Aires";
  var q5datos = window.NBA_HOY || null;
  var q5jugados = window.NBA_JUGADOS || null;
  var q5medido = window.NBA_MEDIDO || null;
  var q5cuentas = window.q5Cuentas;
  var q5acceso = { abierto: !(q5cuentas && q5cuentas.configurado), motivo: "cargando", cobra: false, diasPrueba: 3 };
  var q5planes = [];
  var $ = function (id) { return document.getElementById(id); };

  /* ── utilidades ── */
  function q5Phi(x) {
    var t = 1 / (1 + 0.2316419 * Math.abs(x));
    var d = 0.3989423 * Math.exp(-x * x / 2);
    var p = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
    return x >= 0 ? 1 - p : p;
  }
  function q5PesoVisible(peso) { return (peso >= Q5_BANDA.desde && peso <= Q5_BANDA.hasta) ? 0 : peso; }
  function q5Num(x, dec) { return x.toLocaleString("es-AR", { minimumFractionDigits: dec, maximumFractionDigits: dec }); }
  function q5Signo(x, dec) { return (x > 0 ? "+" : x < 0 ? "−" : "") + q5Num(Math.abs(x), dec); }
  function q5Pct(p) { return Math.round(p * 100) + "%"; }
  function q5Hora(iso) { try { return new Intl.DateTimeFormat("es-AR", { timeZone: Q5_HORARIA, hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(iso)); } catch (e) { return ""; } }
  function q5Dia(iso) { try { var d = new Intl.DateTimeFormat("es-AR", { timeZone: Q5_HORARIA, weekday: "long", day: "numeric", month: "long" }).format(new Date(iso)); return d.charAt(0).toUpperCase() + d.slice(1); } catch (e) { return ""; } }
  function q5El(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function q5Esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function q5Guardar(k, v) { try { if (v == null || v === "") localStorage.removeItem("q5." + k); else localStorage.setItem("q5." + k, v); } catch (e) {} }
  function q5Leer(k) { try { return localStorage.getItem("q5." + k); } catch (e) { return null; } }
  var Q5_ESTADO = { Out: "no juega", Doubtful: "casi seguro no juega", Questionable: "en duda", Probable: "probable", Available: "disponible" };
  var Q5_MOTIVO = [[/Injury\/Illness - /i, ""], [/Left /i, "izq. "], [/Right /i, "der. "], [/Knee/i, "rodilla"], [/Ankle/i, "tobillo"], [/Hamstring/i, "isquiotibial"], [/Calf/i, "pantorrilla"], [/Back/i, "espalda"], [/Shoulder/i, "hombro"], [/Wrist/i, "muñeca"], [/Hand/i, "mano"], [/Foot/i, "pie"], [/Hip/i, "cadera"], [/Illness/i, "enfermedad"], [/Soreness/i, "molestia"], [/Sprain/i, "esguince"], [/Strain/i, "desgarro"], [/Contusion/i, "golpe"], [/Rest/i, "descanso"], [/Injury Management/i, "manejo de la lesión"], [/Return to Competition Reconditioning/i, "puesta a punto"], [/G League/i, "G League"], [/Personal/i, "motivo personal"], [/Surgery/i, "cirugía"], [/Fracture/i, "fractura"], [/Concussion Protocol/i, "protocolo de conmoción"]];
  function q5Motivo(m) { if (!m) return ""; Q5_MOTIVO.forEach(function (r) { m = m.replace(r[0], r[1]); }); return m.replace(/;/g, ",").trim(); }
  function q5Compartir(texto) {
    var t = texto + "\narmaelquinteto.com";
    if (navigator.share) return navigator.share({ text: t }).catch(function () {});
    if (navigator.clipboard) return navigator.clipboard.writeText(t).then(function () { alert("Copiado. Pegalo donde quieras."); }).catch(function () {});
  }

  /* ── el estado y la cuenta de un partido ── */
  function q5Estado(p) {
    var fuera = {};
    p.local.jugadores.concat(p.visita.jugadores).forEach(function (j) { if (j.ausente) fuera[j.id] = true; });
    return { fuera: fuera };
  }
  function q5Calcular(p, est) {
    var base = p.m0.margen + p.modelo.b2b * (p.visita.b2b - p.local.b2b);
    var margen = base;
    p.local.jugadores.forEach(function (j) { if (est.fuera[j.id]) margen -= q5PesoVisible(j.peso); });
    p.visita.jugadores.forEach(function (j) { if (est.fuera[j.id]) margen += q5PesoVisible(j.peso); });
    return { margen: margen, p: q5Phi(margen / p.modelo.desvio), base: base, pBase: q5Phi(base / p.modelo.desvio) };
  }

  /* ── la cabecera ── */
  function q5Cabecera() {
    var sub = $("q5-sub");
    if (!q5datos) { sub.innerHTML = "<span>no hay datos todavía</span>"; return; }
    var parte = q5datos.parte && q5datos.parte.fecha
      ? "Parte de lesionados oficial del " + q5datos.parte.fecha.split("-").reverse().slice(0, 2).join("/") + (q5datos.parte.hora ? " · " + q5datos.parte.hora : "")
      : "Sin parte de lesionados: todos disponibles";
    sub.innerHTML = "<span>" + q5Esc(parte) + (q5datos.generado ? " · actualizado " + q5Esc(q5Hora(q5datos.generado)) : "") + "</span>";
  }

  /* ── la baja de la noche ── */
  function q5Baja() {
    var cont = $("q5-baja"); cont.innerHTML = "";
    var b = q5datos && q5datos.baja; if (!b) return;
    var frase = "Sin <b>" + q5Esc(b.jugador.split(" ").slice(-1)[0]) + "</b>, " + q5Esc(b.equipo) + " pasa de <b>" + q5Pct(b.pCon) + "</b> a <b>" + q5Pct(b.pSin) + "</b>";
    var card = q5El("div", "q5-baja");
    card.innerHTML = '<svg class="pelota" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="48" fill="#fff"/></svg>' +
      '<div class="eti">La baja de la noche</div><div class="frase">' + frase + "</div>" +
      '<div class="det">' + q5Esc(Q5_ESTADO[b.estado] || b.estado || "no juega") + (b.motivo ? " · " + q5Esc(q5Motivo(b.motivo)) : "") + " · " + (b.local ? "recibe a" : "visita a") + " " + q5Esc(b.rival) + " · " + q5Esc(q5Hora(b.fecha)) + " · " + q5Signo(-b.peso, 1) + " puntos de margen</div>" +
      '<div class="acc"><button type="button" class="ver">Ver el partido</button><button type="button" class="sec comp">Compartir</button></div>';
    card.querySelector(".ver").addEventListener("click", function () { var el = document.querySelector('[data-partido="' + b.id + '"]'); if (el) { el.classList.add("abierto"); el.scrollIntoView({ behavior: "smooth", block: "start" }); } });
    card.querySelector(".comp").addEventListener("click", function () { q5Compartir("La baja de la noche: sin " + b.jugador + ", " + b.equipo + " pasa de " + q5Pct(b.pCon) + " a " + q5Pct(b.pSin) + " contra " + b.rival + "."); });
    cont.appendChild(card);
  }

  /* ── un equipo en la cabecera de la tarjeta ── */
  function q5Equipo(e, lado) {
    var d = q5El("div", "eq " + lado + (lado === "loc" ? " der" : ""));
    var det = (lado === "loc" ? "local" : "visitante") + (e.b2b ? " · <i>jugó ayer</i>" : e.descanso >= 3 ? " · " + e.descanso + " días de descanso" : "");
    d.innerHTML = '<div class="mono">' + q5Esc(e.codigo || "?") + '</div><div><div class="nom">' + q5Esc(e.apodo || e.nombre || e.id) + '</div><div class="det">' + det + "</div></div>";
    return d;
  }

  /* ── el candado: lo que ve el que no tiene pase ── */
  function q5Candado() {
    var c = q5El("div", "candado");
    var plan = q5planes[0];
    var precio = plan && plan.precio ? '<div class="precio">$' + q5Num(+plan.precio, 0) + " <small>por " + (plan.meses > 1 ? plan.meses + " meses" : "mes") + ", con Mercado Pago</small></div>" : "";
    var titulo, texto;
    if (q5acceso.motivo === "sin-cuenta") { titulo = "Probalo " + q5acceso.diasPrueba + " días gratis"; texto = "Entrá o creá tu cuenta y ves el número y la rotación de todos los partidos. Después, el pase."; }
    else if (q5acceso.motivo === "vencida") { titulo = "Terminó tu prueba gratis"; texto = "Con el pase seguís viendo el número y la rotación de todos los partidos."; }
    else { titulo = "No pudimos consultar tu pase"; texto = "Fijate la conexión y volvé a abrir la app."; }
    c.innerHTML = "<b>" + q5Esc(titulo) + "</b><p>" + q5Esc(texto) + "</p>" + precio;
    var acc = q5El("div");
    if (q5acceso.motivo === "sin-cuenta") { var b = q5El("button", "q5-btn", "Entrar o crear cuenta"); b.type = "button"; b.addEventListener("click", function () { q5IrA("ajustes"); $("q5-mail").focus(); }); acc.appendChild(b); }
    else if (q5acceso.motivo === "vencida") { var b2 = q5El("button", "q5-btn", "Sacar el pase"); b2.type = "button"; b2.addEventListener("click", q5Pagar); acc.appendChild(b2); }
    c.appendChild(acc);
    return c;
  }
  function q5Pagar(ev) {
    var b = ev && ev.currentTarget; if (b) { b.disabled = true; b.textContent = "Abriendo Mercado Pago…"; }
    q5cuentas.linkDePago().then(function (link) { if (link) location.href = link; else throw new Error("sin link"); })
      .catch(function () { if (b) { b.disabled = false; b.textContent = "Sacar el pase"; } alert("No pudimos armar el pago. Probá de nuevo en un rato."); });
  }

  /* ── la tarjeta de un partido, con la rotación ── */
  function q5Partido(p, esPuerta) {
    var est = q5Estado(p);
    var card = q5El("article", "partido" + (esPuerta ? " puerta abierto" : "")); card.dataset.partido = p.id;
    var cab = q5El("div", "cab");
    cab.appendChild(q5Equipo(p.visita, "vis"));
    cab.appendChild(q5El("div", "vs", q5Esc(q5Dia(p.fecha).split(",")[0]) + " · arg.<b>" + q5Esc(q5Hora(p.fecha)) + "</b>"));
    cab.appendChild(q5Equipo(p.local, "loc"));
    card.appendChild(cab);
    if (!q5acceso.abierto) { card.appendChild(q5acceso.motivo === "cargando" ? q5El("div", "ausentes", "consultando tu pase…") : esPuerta ? q5Candado() : q5El("div", "ausentes", "Con el pase: el número y la rotación.")); return card; }

    var barra = q5El("div", "barra"); var bv = q5El("div", "v"), bl = q5El("div", "l"); barra.appendChild(bv); barra.appendChild(bl); card.appendChild(barra);
    var leyenda = q5El("div", "leyenda"); card.appendChild(leyenda);
    var ausentes = q5El("div", "ausentes"); card.appendChild(ausentes);
    var abrir = q5El("button", "abrir", esPuerta ? "cerrar la rotación" : "armá el quinteto"); abrir.type = "button"; card.appendChild(abrir);
    var rot = q5El("div", "rot"); card.appendChild(rot);

    function pintar() {
      var c = q5Calcular(p, est);
      var pl = Math.round(c.p * 100), pv = 100 - pl;
      bv.style.width = pv + "%"; bl.style.width = pl + "%";
      bv.textContent = pv >= 12 ? pv + "%" : ""; bl.textContent = pl >= 12 ? pl + "%" : "";
      bv.classList.toggle("fav", pv > pl); bl.classList.toggle("fav", pl >= pv);
      var fav = c.margen >= 0 ? p.local : p.visita;
      var m = Math.abs(c.margen);
      var txt = "<span>" + q5Esc(fav.apodo || fav.codigo) + " por <b>" + q5Num(m, 1) + "</b>" + (m < 1.5 ? " · parejo" : "") + "</span>";
      var dif = c.p - c.pBase;
      txt += "<span class='cambio'>" + (Math.abs(dif) >= 0.005 ? "con las bajas, " + q5Signo(Math.round(dif * 100), 0) + " pts para el local" : "sin bajas que pesen") + "</span>";
      leyenda.innerHTML = txt;
      var lista = [];
      [p.visita, p.local].forEach(function (e) {
        e.jugadores.forEach(function (j) {
          if (!est.fuera[j.id]) return;
          var pv2 = q5PesoVisible(j.peso);
          lista.push("<b>" + q5Esc(j.n) + "</b> (" + q5Esc(e.codigo) + ") " + (pv2 ? q5Signo(-pv2, 1) : "≈ 0") + (j.ausente ? "" : " · lo sacaste vos"));
        });
      });
      ausentes.innerHTML = lista.length ? "No juegan: " + lista.join(" · ") : "";
      rot.querySelectorAll(".jug").forEach(function (fila) { fila.classList.toggle("juega", !est.fuera[fila.dataset.id]); });
    }
    function listaDe(e, lado) {
      rot.appendChild(q5El("h3", null, q5Esc(e.apodo || e.nombre) + " <span class='prod'>" + (lado === "loc" ? "local" : "visitante") + "</span>"));
      e.jugadores.forEach(function (j) {
        var fila = q5El("div", "jug"); fila.dataset.id = j.id;
        var pv2 = q5PesoVisible(j.peso);
        var estado = j.estado ? "<span class='est" + (j.ausente ? " out" : "") + "'>" + q5Esc(Q5_ESTADO[j.estado] || j.estado) + "</span>" + (j.motivo ? " · " + q5Esc(q5Motivo(j.motivo)) : "") : "";
        fila.innerHTML = '<button type="button" class="sw" role="switch" aria-label="juega"></button>' +
          '<div class="n"><b>' + q5Esc(j.n) + "</b><small>" + (estado || j.partidos + " partidos") + "</small></div>" +
          '<div class="min">' + q5Num(j.min, 0) + "′</div>" +
          '<div class="peso' + (pv2 ? "" : " nada") + '">' + (pv2 ? q5Signo(-pv2, 1) : "≈ 0") + "</div>";
        fila.querySelector(".sw").addEventListener("click", function () { if (est.fuera[j.id]) delete est.fuera[j.id]; else est.fuera[j.id] = true; pintar(); });
        rot.appendChild(fila);
      });
    }
    listaDe(p.visita, "vis"); listaDe(p.local, "loc");
    var acc = q5El("div", "acciones");
    var bParte = q5El("button", null, "volver al parte"), bTodos = q5El("button", null, "todos juegan"), bComp = q5El("button", null, "compartir");
    bParte.type = bTodos.type = bComp.type = "button";
    bParte.addEventListener("click", function () { est.fuera = q5Estado(p).fuera; pintar(); });
    bTodos.addEventListener("click", function () { est.fuera = {}; pintar(); });
    bComp.addEventListener("click", function () { var c = q5Calcular(p, est); var fav = c.margen >= 0 ? p.local : p.visita; q5Compartir((p.visita.apodo || p.visita.codigo) + " @ " + (p.local.apodo || p.local.codigo) + ": " + (fav.apodo || fav.codigo) + " " + q5Pct(Math.max(c.p, 1 - c.p)) + ", por " + q5Num(Math.abs(c.margen), 1) + " puntos."); });
    acc.appendChild(bParte); acc.appendChild(bTodos); acc.appendChild(bComp); rot.appendChild(acc);
    rot.appendChild(q5El("div", "nota", "El peso es cuántos puntos de margen se mueven si ese jugador no juega, con sus minutos habituales y su producción por minuto. \"≈ 0\": el modelo no le ve efecto medible. Minutos: los habituales, no los de hoy."));
    function alternar() { card.classList.toggle("abierto"); abrir.textContent = card.classList.contains("abierto") ? "cerrar la rotación" : "armá el quinteto"; }
    abrir.addEventListener("click", alternar);
    cab.addEventListener("click", alternar);
    pintar();
    return card;
  }

  /* ── HOY: la puerta y los otros ── */
  function q5Hoy() {
    q5Cabecera(); q5Baja();
    var puerta = $("q5-puerta"), otros = $("q5-otros"); puerta.innerHTML = ""; otros.innerHTML = "";
    if (!q5datos || !q5datos.partidos || !q5datos.partidos.length) {
      puerta.appendChild(q5El("div", "vacio", "<b>No hay partidos en las próximas 48 horas.</b><br>La temporada regular de la NBA va de octubre a abril; los playoffs, hasta junio. Volvé cuando haya fecha."));
      $("q5-otros-titulo").classList.add("oculto"); return;
    }
    var orden = q5datos.partidos.slice().sort(function (a, b) { return new Date(a.fecha) - new Date(b.fecha); });
    var seguido = q5Leer("equipo");
    var principal = (seguido && orden.filter(function (p) { return String(p.local.id) === seguido || String(p.visita.id) === seguido; })[0]) || orden[0];
    puerta.appendChild(q5Partido(principal, true));
    var resto = orden.filter(function (p) { return p !== principal; });
    $("q5-otros-titulo").classList.toggle("oculto", !resto.length);
    var dia = null;
    resto.forEach(function (p) { var d = q5Dia(p.fecha); if (d !== dia) { dia = d; otros.appendChild(q5El("h2", "q5-dia", q5Esc(d))); } otros.appendChild(q5Partido(p, false)); });
  }

  /* ── JUGADOS ── */
  function q5Jugados() {
    var cont = $("q5-jugados"); cont.innerHTML = "";
    var lista = q5jugados && q5jugados.partidos || [];
    if (!lista.length) { cont.appendChild(q5El("div", "vacio", "<b>Todavía no hay partidos jugados con pronóstico guardado.</b><br>Desde el primer partido de la temporada, acá queda lo que el modelo dijo y lo que pasó.")); return; }
    var dia = null;
    lista.forEach(function (j) {
      var d = q5Dia(j.fecha); if (d !== dia) { dia = d; cont.appendChild(q5El("h2", "q5-dia", q5Esc(d))); }
      var favLocal = j.p >= 0.5, fav = favLocal ? j.local : j.visita, pFav = Math.max(j.p, 1 - j.p);
      var fila = q5El("div", "jugado");
      fila.innerHTML = '<div class="punto ' + q5Esc(j.punto) + '"></div><div class="q">' + q5Esc(j.visita.codigo || j.visita.id) + " @ " + q5Esc(j.local.codigo || j.local.id) +
        "<small>daba " + q5Esc(fav.apodo || fav.codigo) + " " + q5Pct(pFav) + ", por " + q5Num(Math.abs(j.margen), 1) + "</small></div>" +
        '<div class="r">' + j.pv + " – " + j.pl + "<small>" + (j.punto === "verde" ? "ganó el favorito" : j.punto === "gris" ? "daba parejo" : "sorpresa") + "</small></div>";
      cont.appendChild(fila);
    });
  }

  /* ── ESTÁ MEDIDO ── */
  function q5Medido() {
    var g = $("q5-medido-grande"); g.innerHTML = "";
    var L = q5medido && q5medido.limpia;
    var cajas = L ? [[q5Pct(L.acierta.m1d), "acierta el ganador en " + q5Num(L.partidos, 0) + " partidos que nunca había visto (2023-25)"], [q5Pct(L.acierta.mejorRecord), "acierta \"el de mejor récord\" en los mismos partidos"], ["+" + q5Num(L.margen.b2b.puntos, 1), "puntos pierde un equipo que jugó ayer (t " + q5Num(L.margen.b2b.t, 1) + ")"], ["0,3", "puntos menos de error en el margen cuando falta un titular y se lo cuenta (t " + q5Num(L.margen.h5.t, 1) + ")"]] : [];
    cajas.forEach(function (c) { g.appendChild(q5El("div", "caja", "<b>" + q5Esc(c[0]) + "</b><span>" + q5Esc(c[1]) + "</span>")); });
    var tb = $("q5-cal").querySelector("tbody"); tb.innerHTML = "";
    var T = q5medido && q5medido.trabajo;
    if (T) {
      T.calibracion.forEach(function (c) { tb.appendChild(q5El("tr", null, "<td>" + q5Pct(c.dice) + "</td><td><b>" + q5Pct(c.pasa) + "</b></td><td>" + q5Num(c.n, 0) + "</td>")); });
      $("q5-cal-pie").textContent = "La tabla es sobre las " + T.temporadas.length + " temporadas con las que se armó el modelo (" + q5Num(T.partidos, 0) + " partidos, local gana). Los números grandes son de la prueba sobre datos nunca vistos.";
    }
  }

  /* ── AJUSTES: tema y equipo ── */
  function q5Tema(t) {
    if (t === "auto" || !t) document.documentElement.removeAttribute("data-tema"); else document.documentElement.setAttribute("data-tema", t);
    q5Guardar("tema", t === "auto" ? null : t);
    $("q5-tema").querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.tema === (t || "auto")); });
  }
  function q5Ajustes() {
    q5Tema(q5Leer("tema") || "auto");
    $("q5-tema").addEventListener("click", function (ev) { var b = ev.target.closest("button"); if (b) q5Tema(b.dataset.tema); });
    var sel = $("q5-equipo"), vistos = {};
    (q5datos && q5datos.partidos || []).forEach(function (p) { [p.local, p.visita].forEach(function (e) { if (!vistos[e.id]) { vistos[e.id] = e; } }); });
    Object.keys(vistos).map(function (k) { return vistos[k]; }).sort(function (a, b) { return (a.nombre || "").localeCompare(b.nombre || ""); }).forEach(function (e) { var o = document.createElement("option"); o.value = e.id; o.textContent = e.nombre || e.apodo || e.codigo; sel.appendChild(o); });
    sel.value = q5Leer("equipo") || "";
    sel.addEventListener("change", function () { q5Guardar("equipo", sel.value); q5Hoy(); });
  }

  /* ── LA CUENTA ── */
  function q5Cuenta() {
    var estado = $("q5-cuenta-estado"), form = $("q5-form"), msj = $("q5-form-msj"), boton = $("q5-boton-cuenta"), franja = $("q5-franja");
    var s = q5acceso.sesion;
    estado.innerHTML = ""; franja.classList.add("oculto"); boton.classList.remove("pase");
    if (!q5cuentas.configurado) { estado.innerHTML = "<p>Sin cuenta por ahora: todo abierto.</p>"; form.classList.add("oculto"); boton.classList.add("oculto"); return; }
    boton.classList.remove("oculto");
    if (!s) {
      estado.innerHTML = "<p>" + (q5acceso.cobra ? "Sin cuenta ves quién juega y cuándo, la baja de la noche, los jugados y \"Está medido\". Con cuenta, " + q5acceso.diasPrueba + " días gratis del número y la rotación." : "Con cuenta, tu equipo te sigue de un teléfono a otro.") + "</p>";
      form.classList.remove("oculto"); boton.textContent = q5acceso.cobra ? "Probar gratis" : "Entrar"; return;
    }
    form.classList.add("oculto");
    var html = "<p>Entraste como <b>" + q5Esc(s.user && s.user.email || "") + "</b>.</p>";
    if (q5acceso.motivo === "pase") { html += "<p>Tenés el pase hasta el <b>" + q5Esc(new Date(q5acceso.hasta).toLocaleDateString("es-AR")) + "</b>.</p>"; boton.textContent = "Con el pase"; boton.classList.add("pase"); }
    else if (q5acceso.motivo === "prueba") { html += "<p>Estás en la prueba gratis: " + q5Esc(q5Queda(q5acceso.prueba.hasta)) + ". Después, el pase.</p>"; boton.textContent = "Prueba · " + q5Queda(q5acceso.prueba.hasta, true); franja.classList.remove("oculto"); franja.innerHTML = "<span>Prueba gratis · te quedan " + q5Esc(q5Queda(q5acceso.prueba.hasta)) + "</span>"; var bf = q5El("button", null, "Sacar el pase"); bf.type = "button"; bf.addEventListener("click", q5Pagar); franja.appendChild(bf); }
    else if (q5acceso.motivo === "vencida") { html += "<p>Terminó tu prueba gratis. Con el pase seguís viendo el número y la rotación.</p>"; boton.textContent = "Sacar el pase"; }
    else { html += "<p>Todo abierto.</p>"; boton.textContent = "Tu cuenta"; }
    estado.innerHTML = html;
    if (q5acceso.cobra && q5acceso.motivo !== "pase") { var bp = q5El("button", "q5-btn", "Sacar el pase" + (q5planes[0] && q5planes[0].precio ? " · $" + q5Num(+q5planes[0].precio, 0) : "")); bp.type = "button"; bp.addEventListener("click", q5Pagar); estado.appendChild(bp); }
    var bs = q5El("button", "q5-btn sec", "Salir"); bs.type = "button"; bs.style.marginLeft = "8px";
    bs.addEventListener("click", function () { q5cuentas.salir().then(q5Arrancar); }); estado.appendChild(bs);
  }
  function q5Queda(hasta, corto) {
    var ms = Math.max(0, +new Date(hasta) - Date.now()), d = Math.floor(ms / 864e5), h = Math.floor((ms % 864e5) / 36e5), m = Math.floor((ms % 36e5) / 6e4);
    if (corto) return d ? d + " d " + h + " h" : h + " h " + m + " min";
    return d ? d + " día" + (d > 1 ? "s" : "") + " y " + h + " h" : h + " h y " + m + " min";
  }
  function q5FormCuenta() {
    var form = $("q5-form"), msj = $("q5-form-msj");
    function decir(t, ok) { msj.innerHTML = t ? "<div class='" + (ok ? "q5-ok" : "q5-error") + "'>" + q5Esc(t) + "</div>" : ""; }
    form.addEventListener("submit", function (ev) { ev.preventDefault(); decir(""); q5cuentas.entrar($("q5-mail").value.trim(), $("q5-clave").value).then(q5Arrancar).catch(function (e) { decir("No pudimos entrar: " + (e.message || "fijate el mail y la contraseña")); }); });
    $("q5-crear").addEventListener("click", function () { decir(""); if (!$("q5-mail").value || $("q5-clave").value.length < 6) { decir("Poné tu mail y una contraseña de 6 o más."); return; } q5cuentas.crear($("q5-mail").value.trim(), $("q5-clave").value).then(function (r) { if (r.confirmar) decir("Te mandamos un mail para confirmar la cuenta. Abrilo y volvé.", true); else q5Arrancar(); }).catch(function (e) { decir("No pudimos crear la cuenta: " + (e.message || "")); }); });
    $("q5-link").addEventListener("click", function () { decir(""); if (!$("q5-mail").value) { decir("Poné tu mail."); return; } q5cuentas.link($("q5-mail").value.trim()).then(function () { decir("Te mandamos un link. Abrilo desde este teléfono.", true); }).catch(function (e) { decir("No salió el mail: " + (e.message || "")); }); });
    $("q5-boton-cuenta").addEventListener("click", function () { if (q5acceso.motivo === "vencida" && q5acceso.sesion) q5Pagar({ currentTarget: $("q5-boton-cuenta") }); else { q5IrA("ajustes"); $("q5-cuenta").scrollIntoView({ behavior: "smooth" }); if (!q5acceso.sesion) $("q5-mail").focus(); } });
  }

  /* ── las pestañas ── */
  function q5IrA(sec) {
    document.querySelectorAll("section.q5-sec").forEach(function (s) { s.classList.toggle("activa", s.id === "sec-" + sec); });
    $("q5-nav").querySelectorAll("button").forEach(function (b) { b.classList.toggle("on", b.dataset.sec === sec); });
    window.scrollTo({ top: 0 });
  }
  $("q5-nav").addEventListener("click", function (ev) { var b = ev.target.closest("button"); if (b) q5IrA(b.dataset.sec); });

  /* ── arranque: pintar lo gratis ya, consultar el acceso, repintar ── */
  var q5reloj = null;
  function q5Arrancar() {
    return q5cuentas.acceso().then(function (a) {
      q5acceso = a;
      return (a.cobra && a.motivo !== "pase" ? q5cuentas.planes() : Promise.resolve([])).then(function (pl) { q5planes = pl || []; });
    }).catch(function () { q5acceso = { abierto: false, motivo: "sin-servidor", cobra: true, diasPrueba: 3 }; })
      .then(function () {
        q5Hoy(); q5Cuenta();
        if (q5reloj) clearInterval(q5reloj);
        if (q5acceso.motivo === "prueba") q5reloj = setInterval(function () { if (+new Date(q5acceso.prueba.hasta) <= Date.now()) { q5Arrancar(); } else q5Cuenta(); }, 30000);
      });
  }
  q5Jugados(); q5Medido(); q5Ajustes(); q5FormCuenta();
  q5Hoy(); q5Cuenta();     /* con lo gratis ya pintado, se consulta el acceso */
  q5Arrancar();
  if (/^#(hoy|jugados|medido|ajustes)$/.test(location.hash)) q5IrA(location.hash.slice(1));

  /* para probar desde la consola */
  window.q5 = { calcular: q5Calcular, pesoVisible: q5PesoVisible, banda: Q5_BANDA, Phi: q5Phi, motivo: q5Motivo, irA: q5IrA, acceso: function () { return q5acceso; } };
})();
