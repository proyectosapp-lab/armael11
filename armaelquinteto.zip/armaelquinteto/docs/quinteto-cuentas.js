/* ══════════════════════════════════════════════════════════════════════════
   QUINTETO-CUENTAS.JS — la cuenta, el pase y la prueba gratis de Armá el
   Quinteto. Es LA MISMA cuenta que Armá el 11 y Sacá vos: el mismo
   Supabase, la misma tabla `perfil`, la misma llave de sesión en el
   navegador (`tste.sesion`). Entrar en una es entrar en las tres.

   Habla con Supabase por REST, sin librería: son seis pedidos. Las dos
   claves públicas viven en sitio.js (window.Q5_SITIO). Sin ellas, la app
   corre en modo abierto: no pide cuenta ni cobra (para probar en local).

   Lo que decide el ACCESO lo decide el servidor:
     · ajuste `cobra_quinteto`: 'no' → todo abierto para todos;
     · tabla `pase` (producto 'quinteto', hasta): el pase pago;
     · rpc `mi_prueba_quinteto()`: la prueba gratis por cuenta, que empieza
       la primera vez que la persona entra y no se alarga borrando nada.
   El precio también lo pone el servidor (crear-pago): acá no hay números.

   Script clásico, ámbito global: todo lo de acá vive en window.q5Cuentas.
   ══════════════════════════════════════════════════════════════════════════ */
(function () {
  "use strict";
  var LLAVE = "tste.sesion";
  var PRODUCTO = "quinteto";
  var cfg = window.Q5_SITIO || {};
  var url = (cfg.supabaseUrl || "").replace(/\/$/, "");
  var anon = cfg.supabaseAnon || "";
  var configurado = !!(url && anon);

  /* ── la sesión en el teléfono ── */
  function leerSesion() { try { return JSON.parse(localStorage.getItem(LLAVE) || "null"); } catch (e) { return null; } }
  function guardarSesion(s) { try { if (s) localStorage.setItem(LLAVE, JSON.stringify(s)); else localStorage.removeItem(LLAVE); } catch (e) {} }
  function sesionDe(r) {
    if (!r || !r.access_token) return null;
    return { access_token: r.access_token, refresh_token: r.refresh_token, expires_at: r.expires_at || (Math.floor(Date.now() / 1000) + (r.expires_in || 3600)), user: { id: r.user && r.user.id, email: r.user && r.user.email } };
  }

  /* ── un pedido a Supabase ── */
  function pedir(ruta, opciones) {
    opciones = opciones || {};
    var s = leerSesion();
    var cab = { apikey: anon, "Content-Type": "application/json" };
    cab.Authorization = "Bearer " + (opciones.anon || !s ? anon : s.access_token);
    if (opciones.prefer) cab.Prefer = opciones.prefer;
    return fetch(url + ruta, { method: opciones.metodo || "GET", headers: cab, body: opciones.cuerpo ? JSON.stringify(opciones.cuerpo) : undefined })
      .then(function (r) {
        return r.text().then(function (t) {
          var j = null; try { j = t ? JSON.parse(t) : null; } catch (e) { j = { crudo: t }; }
          if (!r.ok) { var err = new Error((j && (j.msg || j.message || j.error_description || j.error)) || ("error " + r.status)); err.estado = r.status; err.cuerpo = j; throw err; }
          return j;
        });
      });
  }

  /* Renueva el token si vence en menos de un minuto. */
  function asegurarSesion() {
    var s = leerSesion();
    if (!s) return Promise.resolve(null);
    if (s.expires_at - Math.floor(Date.now() / 1000) > 60) return Promise.resolve(s);
    return pedir("/auth/v1/token?grant_type=refresh_token", { metodo: "POST", anon: true, cuerpo: { refresh_token: s.refresh_token } })
      .then(function (r) { var n = sesionDe(r); guardarSesion(n); return n; })
      .catch(function () { guardarSesion(null); return null; });
  }

  /* Al entrar por primera vez, la fila de perfil. `ignore-duplicates`:
     nunca pisa el usuario que la persona ya tiene en Armá el 11. */
  function asegurarPerfil(s) {
    if (!s || !s.user || !s.user.id) return Promise.resolve();
    return pedir("/rest/v1/perfil", { metodo: "POST", prefer: "resolution=ignore-duplicates,return=minimal", cuerpo: { id: s.user.id, usuario: "q5_" + s.user.id.slice(0, 8) } }).catch(function () {});
  }

  /* ── entrar, crear, link, salir ── */
  function entrar(mail, clave) {
    return pedir("/auth/v1/token?grant_type=password", { metodo: "POST", anon: true, cuerpo: { email: mail, password: clave } })
      .then(function (r) { var s = sesionDe(r); guardarSesion(s); return asegurarPerfil(s).then(function () { return s; }); });
  }
  function crear(mail, clave) {
    return pedir("/auth/v1/signup", { metodo: "POST", anon: true, cuerpo: { email: mail, password: clave, options: { emailRedirectTo: location.origin + location.pathname } } })
      .then(function (r) {
        var s = sesionDe(r);
        if (s) { guardarSesion(s); return asegurarPerfil(s).then(function () { return { sesion: s }; }); }
        return { confirmar: true };   /* Supabase manda el mail de confirmación */
      });
  }
  function link(mail) {
    return pedir("/auth/v1/otp", { metodo: "POST", anon: true, cuerpo: { email: mail, create_user: false, options: { emailRedirectTo: location.origin + location.pathname } } });
  }
  function salir() {
    var s = leerSesion(); guardarSesion(null);
    if (!s) return Promise.resolve();
    return pedir("/auth/v1/logout", { metodo: "POST" }).catch(function () {});
  }
  /* El link por mail vuelve con #access_token=…: lo tomamos y lo borramos. */
  function tomarDelLink() {
    if (!/access_token=/.test(location.hash)) return Promise.resolve(false);
    var q = {}; location.hash.slice(1).split("&").forEach(function (kv) { var p = kv.split("="); q[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ""); });
    var s = sesionDe({ access_token: q.access_token, refresh_token: q.refresh_token, expires_in: +q.expires_in || 3600, user: {} });
    if (!s) return Promise.resolve(false);
    guardarSesion(s);
    history.replaceState(null, "", location.pathname + location.search);
    return pedir("/auth/v1/user").then(function (u) { s.user = { id: u.id, email: u.email }; guardarSesion(s); return asegurarPerfil(s); }).then(function () { return true; });
  }

  /* ── el pase, la prueba y los ajustes ── */
  function ajustes() {
    return pedir("/rest/v1/ajuste?select=clave,valor&clave=in.(cobra_" + PRODUCTO + ",prueba_" + PRODUCTO + "_dias)", { anon: true })
      .then(function (filas) { var a = {}; (filas || []).forEach(function (f) { a[f.clave] = f.valor; }); return a; });
  }
  function miPase() {
    return pedir("/rest/v1/pase?select=hasta&producto=eq." + PRODUCTO + "&order=hasta.desc&limit=1")
      .then(function (filas) { return filas && filas[0] ? filas[0].hasta : null; });
  }
  function miPrueba() {
    return pedir("/rest/v1/rpc/mi_prueba_" + PRODUCTO, { metodo: "POST", cuerpo: {} })
      .then(function (r) { var f = Array.isArray(r) ? r[0] : r; return f && f.hasta ? { desde: f.desde, hasta: f.hasta } : null; });
  }
  function planes() {
    return pedir("/functions/v1/crear-pago?plan=" + PRODUCTO)
      .then(function (r) { var lista = (r && (r.planes || r)) || []; if (!Array.isArray(lista)) lista = [lista]; return lista.filter(function (p) { return p && (p.id === PRODUCTO || p.plan === PRODUCTO || !p.id); }); })
      .catch(function () { return []; });
  }
  function linkDePago() {
    return pedir("/functions/v1/crear-pago", { metodo: "POST", cuerpo: { plan: PRODUCTO, vuelta: (cfg.vuelta || location.origin + "/gracias.html") } })
      .then(function (r) { return r && (r.init_point || r.url || r.link); });
  }

  /* ── el acceso, todo junto ──
     Devuelve { abierto, motivo, sesion, hasta, prueba, cobra, diasPrueba }.
     motivo: 'sin-configurar' | 'sin-cobro' | 'pase' | 'prueba' | 'sin-cuenta' | 'vencida' | 'sin-servidor' */
  function acceso() {
    if (!configurado) return Promise.resolve({ abierto: true, motivo: "sin-configurar", sesion: null, cobra: false, diasPrueba: 3 });
    return tomarDelLink().then(asegurarSesion).then(function (s) {
      return ajustes().then(function (a) {
        var cobra = (a["cobra_" + PRODUCTO] || "no") === "si";
        var dias = +(a["prueba_" + PRODUCTO + "_dias"] || 3) || 3;
        if (!cobra) return { abierto: true, motivo: "sin-cobro", sesion: s, cobra: false, diasPrueba: dias };
        if (!s) return { abierto: false, motivo: "sin-cuenta", sesion: null, cobra: true, diasPrueba: dias };
        return Promise.all([miPase().catch(function () { return null; }), miPrueba().catch(function () { return null; })]).then(function (r) {
          var hasta = r[0], prueba = r[1], ahora = Date.now();
          if (hasta && +new Date(hasta) > ahora) return { abierto: true, motivo: "pase", sesion: s, hasta: hasta, prueba: prueba, cobra: true, diasPrueba: dias };
          if (prueba && +new Date(prueba.hasta) > ahora) return { abierto: true, motivo: "prueba", sesion: s, hasta: hasta, prueba: prueba, cobra: true, diasPrueba: dias };
          return { abierto: false, motivo: "vencida", sesion: s, hasta: hasta, prueba: prueba, cobra: true, diasPrueba: dias };
        });
      }, function () { return { abierto: false, motivo: "sin-servidor", sesion: s, cobra: true, diasPrueba: 3 }; });
    });
  }

  window.q5Cuentas = { configurado: configurado, producto: PRODUCTO, sesion: leerSesion, entrar: entrar, crear: crear, link: link, salir: salir,
    acceso: acceso, miPase: miPase, miPrueba: miPrueba, planes: planes, linkDePago: linkDePago, ajustes: ajustes };
})();
