# Armá el Quinteto — identidad

Decidido el 29/9/2026 por Fausto: nombre **Armá el Quinteto**, color **naranja
pelota**, marca propia con aire de familia (Armá el 11 · Sacá vos · Armá el
Quinteto). Todo lo de acá sale de `marca/armar.mjs`; los archivos listos
están en `marca/salida/`.

## Una frase

*Sacá un jugador y mirá cuánto se mueve el partido.*

## Pilares

- **Armá el quinteto**: un interruptor por jugador. Lo sacás, el partido se
  mueve; lo ponés, vuelve. El parte de lesionados oficial ya viene aplicado.
- **Cuánto mueve**: siempre con el número. "Sin Jokić, Denver pasa de 75% a
  61%". Nunca "afecta mucho".
- **Está medido**: 2.151 partidos que el modelo nunca había visto; acierta el
  67,6% del ganador y, cuando falta un titular, mejora el pronóstico en una
  medida que se mide (H2 y H5). No promete aciertos.

## Voz

La de la familia: argentina, de vos, corta, sin exclamaciones, sin emojis,
sin superlativos. Cuando hay un número, va el número. Prohibidas: *cuota,
pick, fija, value, acertá, ganale a la casa*. Nada de "eficacia". Todo lleva
"app independiente" y "sin cuotas".

## Color

| | hex | uso |
|---|---|---|
| naranja pelota | `#E8731C` | la marca: pelota, botón principal, la barra del favorito |
| naranja texto (papel) | `#A84A08` | el naranja cuando es texto sobre papel (5,1:1) |
| naranja texto (noche) | `#F7A45A` | el naranja cuando es texto sobre noche (9,4:1) |
| papel | `#F6F1EA` | fondo del tema claro (familia) |
| tinta | `#14110F` | texto sobre papel (familia) |
| noche | `#0D1117` | fondo del tema noche (familia) |
| local / visitante | `#2A5FA8` / `#8A2E2E` | los dos lados de la barra: dato, no marca |

`#E8731C` no alcanza como texto sobre papel (2,7:1): para texto se usan las
dos variantes. El verde de Armá el 11 y el polvo de Sacá vos no aparecen.

## Marca gráfica

La loseta blanca redondeada de la familia con una pelota naranja adentro:
círculo, las cuatro costuras y el borde en tinta. Las costuras van en tinta
(en Sacá vos van en blanco) para que la pelota se reconozca a 32 px. Sin
logos de la NBA ni de equipos, sin fotos: los equipos son monogramas de tres
letras (ATL, BOS) sobre tinta.

Archivos: `icono.svg` (loseta), `icono-sin-loseta.svg`, `icono-{1024,512,
192,180,48,32}.png`, `apple-icono-1024.png` (sin alfa), `logo-papel` y
`logo-noche` (horizontal, SVG y PNG 1600), `logo-apilado-*` (cuadrado, para
avatar y portadas), `og.png` (1200×630, para compartir), `avatar-instagram.png`
(1080, loseta sobre naranja).

Los SVG del logotipo usan la fuente Poppins por nombre: se ven bien donde
Poppins está instalada o cargada (el sitio la carga). Para imprimir o mandar
a un tercero, usar los PNG.

## Tipografía

Poppins Bold para titulares y números grandes, Medium para texto; sistema
como respaldo. Igual que Armá el 11 y Sacá vos.

## Cuentas y dominios (a verificar por Fausto)

- `armaelquinteto.com` (principal) y `armael5.com` (redirige). Hosting: GitHub
  Pages desde `docs/`; solo se compra el dominio.
- Instagram `@armaelquinteto` (si está tomado, `@armaelquinteto.ok`, como
  `@sacavos.ok`).
- Play `com.armaelquinteto.app`, iPhone el mismo bundle.
