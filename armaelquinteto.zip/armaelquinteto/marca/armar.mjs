/* ARMAR — genera la marca gráfica de Armá el Quinteto: los SVG y los PNG
   en todos los tamaños que piden la web, las tiendas e Instagram.
     node marca/armar.mjs
   Usa sharp (solo acá, en la máquina que arma; el sitio no lo necesita). */
import { createRequire } from "node:module";
const sharp = createRequire(import.meta.url)(process.env.SHARP || "sharp");
import { writeFileSync, mkdirSync } from "node:fs";

export const COLOR = {
  naranja: "#E8731C",       // la pelota: marca, barras, botón
  naranjaTexto: "#A84A08",  // naranja como texto sobre papel (5,1:1)
  naranjaNoche: "#F7A45A",  // naranja como texto sobre noche (9,4:1)
  papel: "#F6F1EA", tinta: "#14110F", noche: "#0D1117", blanco: "#FFFFFF",
  local: "#2A5FA8", visita: "#8A2E2E",   // lados de la barra (dato, no marca)
};

/* La pelota: círculo naranja con las cuatro costuras en tinta.
   `r` radio; centrada en (cx, cy). Las costuras son una vertical, una
   horizontal y dos arcos, como se dibuja una pelota de básquet de memoria. */
export function pelota(cx, cy, r, costura = COLOR.tinta, grosor = r * 0.085) {
  const k = r * 0.62;                       // dónde arrancan los arcos
  return `<g>
  <circle cx="${cx}" cy="${cy}" r="${r}" fill="${COLOR.naranja}"/>
  <g fill="none" stroke="${costura}" stroke-width="${grosor}" stroke-linecap="round">
    <line x1="${cx}" y1="${cy - r}" x2="${cx}" y2="${cy + r}"/>
    <line x1="${cx - r}" y1="${cy}" x2="${cx + r}" y2="${cy}"/>
    <path d="M ${cx - k} ${cy - r * 0.78} Q ${cx - r * 0.05} ${cy} ${cx - k} ${cy + r * 0.78}"/>
    <path d="M ${cx + k} ${cy - r * 0.78} Q ${cx + r * 0.05} ${cy} ${cx + k} ${cy + r * 0.78}"/>
  </g>
  <circle cx="${cx}" cy="${cy}" r="${r - grosor / 2}" fill="none" stroke="${costura}" stroke-width="${grosor}"/>
</g>`;
}

/* La loseta blanca redondeada de la familia, con la pelota adentro. */
export function icono(tam = 512, { fondo = null, loseta = true } = {}) {
  const radio = tam * 0.225, margen = loseta ? tam * 0.06 : 0;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${tam}" height="${tam}" viewBox="0 0 ${tam} ${tam}">
${fondo ? `<rect width="${tam}" height="${tam}" fill="${fondo}"/>` : ""}
${loseta ? `<rect x="${margen}" y="${margen}" width="${tam - 2 * margen}" height="${tam - 2 * margen}" rx="${radio}" fill="${COLOR.blanco}"/>` : ""}
${pelota(tam / 2, tam / 2, tam * 0.30)}
</svg>`;
}

/* El logotipo: loseta + "Armá el Quinteto" en Poppins. `tema` papel o noche. */
export function logo(tema = "papel", { alto = 160, apilado = false } = {}) {
  const tinta = tema === "noche" ? COLOR.blanco : COLOR.tinta;
  const nar = tema === "noche" ? COLOR.naranjaNoche : COLOR.naranjaTexto;
  const fondo = tema === "noche" ? COLOR.noche : COLOR.papel;
  if (!apilado) {
    const ancho = alto * 5.1, ic = alto * 0.8, x = alto * 0.1, y = alto * 0.1;
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${ancho}" height="${alto}" viewBox="0 0 ${ancho} ${alto}" font-family="Poppins, system-ui, sans-serif">
<rect width="${ancho}" height="${alto}" fill="${fondo}"/>
<g transform="translate(${x} ${y})">${icono(ic)}</g>
<text x="${x + ic + alto * 0.18}" y="${alto * 0.615}" font-size="${alto * 0.36}" font-weight="700" fill="${tinta}" letter-spacing="-0.5">Armá el <tspan fill="${nar}">Quinteto</tspan></text>
</svg>`;
  }
  const ancho = alto, ic = alto * 0.52;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${ancho}" height="${alto}" viewBox="0 0 ${ancho} ${alto}" font-family="Poppins, system-ui, sans-serif" text-anchor="middle">
<rect width="${ancho}" height="${alto}" fill="${fondo}"/>
<g transform="translate(${(ancho - ic) / 2} ${alto * 0.06})">${icono(ic)}</g>
<text x="${ancho / 2}" y="${alto * 0.76}" font-size="${alto * 0.115}" font-weight="700" fill="${tinta}">Armá el</text>
<text x="${ancho / 2}" y="${alto * 0.9}" font-size="${alto * 0.135}" font-weight="700" fill="${nar}">Quinteto</text>
</svg>`;
}

/* La imagen de compartir (OG) y el avatar de Instagram. */
export function og() {
  const w = 1200, h = 630;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" font-family="Poppins, system-ui, sans-serif">
<rect width="${w}" height="${h}" fill="${COLOR.noche}"/>
<g transform="translate(90 135)">${icono(360)}</g>
<text x="520" y="290" font-size="76" font-weight="700" fill="${COLOR.blanco}" letter-spacing="-1">Armá el</text>
<text x="520" y="380" font-size="92" font-weight="700" fill="${COLOR.naranjaNoche}" letter-spacing="-1">Quinteto</text>
<text x="520" y="450" font-size="28" font-weight="500" fill="#9aa4b2">Sacá un jugador. Mirá cuánto se mueve.</text>
<text x="520" y="495" font-size="24" font-weight="500" fill="#5c6675">App independiente · sin cuotas · armaelquinteto.com</text>
</svg>`;
}
export function avatar() { return icono(1080, { fondo: COLOR.naranja, loseta: true }); }

async function png(svg, ruta, ancho = null) {
  let s = sharp(Buffer.from(svg), { density: 300 });
  if (ancho) s = s.resize(ancho);
  await s.png().toFile(ruta);
}

if (process.argv[1] && import.meta.url.endsWith("armar.mjs")) {
  const d = new URL("./salida/", import.meta.url).pathname; mkdirSync(d, { recursive: true });
  writeFileSync(d + "icono.svg", icono(512));
  writeFileSync(d + "icono-sin-loseta.svg", icono(512, { loseta: false }));
  writeFileSync(d + "logo-papel.svg", logo("papel"));
  writeFileSync(d + "logo-noche.svg", logo("noche"));
  writeFileSync(d + "logo-apilado-papel.svg", logo("papel", { alto: 600, apilado: true }));
  writeFileSync(d + "logo-apilado-noche.svg", logo("noche", { alto: 600, apilado: true }));
  writeFileSync(d + "og.svg", og());
  writeFileSync(d + "avatar-instagram.svg", avatar());
  for (const t of [1024, 512, 192, 180, 48, 32]) await png(icono(t, { fondo: t >= 180 ? COLOR.blanco : null }), d + `icono-${t}.png`);
  await png(icono(1024, { fondo: COLOR.blanco }), d + "apple-icono-1024.png");   // sin alfa, Apple redondea
  await png(logo("papel", { alto: 160 }), d + "logo-papel.png", 1600);
  await png(logo("noche", { alto: 160 }), d + "logo-noche.png", 1600);
  await png(logo("papel", { alto: 600, apilado: true }), d + "logo-apilado-papel.png", 1200);
  await png(logo("noche", { alto: 600, apilado: true }), d + "logo-apilado-noche.png", 1200);
  await png(og(), d + "og.png", 1200);
  await png(avatar(), d + "avatar-instagram.png", 1080);
  console.log("marca armada en marca/salida/");
}
