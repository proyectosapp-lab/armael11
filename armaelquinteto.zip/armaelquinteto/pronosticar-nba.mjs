/* ══════════════════════════════════════════════════════════════════════════
   PRONOSTICAR-NBA — el motor diario. Con lo jugado hasta hoy y el parte de
   lesionados oficial, arma el pronóstico de los partidos que vienen y todo
   lo que la herramienta de rotación necesita para que el usuario saque o
   ponga jugadores en el navegador.

   Es el MISMO modelo que pasó la prueba limpia (backtest-nba.mjs): vara,
   M0, M1 y M1 + descanso, con los mismos parámetros. No hay un modelo de
   producción distinto del medido. Las dos únicas diferencias, declaradas:

     1. La disponibilidad sale del parte oficial (Out y Doubtful = ausente)
        y no del box score. Era la trampa declarada del backtest; acá es lo
        real, y es lo que el usuario contrasta al otro día.
     2. Los jugadores ARRANCAN la temporada con lo que hicieron en la
        anterior, encogido (n se reinicia a 5 partidos). En el backtest M1
        arrancaba de cero cada temporada; en octubre eso dejaría la
        herramienta vacía. No está medido: es la deuda que se paga con la
        temporada 2026-27, que es la limpia natural de la fase 2.

   QUÉ PUBLICA. `docs/datos/nba-hoy.json` (y .js con window.NBA_HOY): por
   partido, el pronóstico con todos, el pronóstico con el parte aplicado,
   y por equipo el plantel con minutos habituales, producción por minuto,
   estado del parte y "peso" (cuánto se mueve el margen si ese jugador no
   juega). Con eso el navegador recalcula cualquier combinación con la
   misma función `produccion` de backtest-nba.mjs.

     node pronosticar-nba.mjs                     temporada en curso, hoy
     node pronosticar-nba.mjs --temporada 2022 --hasta 2023-03-01   (para probar sin red)

   Todo lo que calcula es puro y está probado sin red en
   probar-pronosticar-nba.mjs. Lo único que toca el disco es `cargarTodo`.
   ══════════════════════════════════════════════════════════════════════════ */
import { readFileSync, readdirSync, existsSync, writeFileSync, mkdirSync } from "node:fs";
import { VARA, M0, M1, Phi, varaNueva, sumarVara, nuevaTemporadaVara, pronosticoVara,
         m0Nuevo, fuerzasM0, pronosticoM0, sumarM0, nuevaTemporadaM0,
         m1Nuevo, sumarM1, anotarFechas, plantel, habitual, produccion, ritmoReemplazo,
         descansoNuevo, diasDesde, anotarDescanso } from "./backtest-nba.mjs";
import { emparejar, AUSENTE } from "./parte.mjs";

const aca = p => new URL(p, import.meta.url);
const DIA = 864e5;

/* Cuántos partidos "vale" lo de la temporada anterior al arrancar. */
export const ARRASTRE_JUGADORES = { n: 5 };
/* Hasta cuántas horas hacia adelante se publican partidos. */
export const HORAS_ADELANTE = 48;

/* ─── el estado, caminando las temporadas ─────────────────────────────── */
/* `temporadas` en orden; la última es la en curso. `hasta` (ISO) corta lo
   jugado, para poder correr "como si fuera" un día del pasado. */
export function armarEstado(temporadas, hasta = null) {
  const V = varaNueva(), E = m0Nuevo(M0), J = m1Nuevo(M1);
  const corte = hasta ? +new Date(hasta) : Infinity;
  let D = descansoNuevo();
  temporadas.forEach((T, i) => {
    if (i > 0) { nuevaTemporadaVara(V); nuevaTemporadaM0(E); arrastrarJugadores(J); }
    D = descansoNuevo();
    anotarFechas(J, T.partidos.filter(p => +new Date(p.fecha) < corte));
    const orden = [...T.partidos].filter(p => +new Date(p.fecha) < corte)
      .sort((a, b) => new Date(a.fecha) - new Date(b.fecha) || a.id - b.id);
    for (const p of orden) {
      sumarVara(V, p.local, p.visita, p.pl, p.pv);
      sumarM0(E, p.local, p.visita, p.pl, p.pv);
      sumarM1(J, p);
      anotarDescanso(D, p.local, p.fecha); anotarDescanso(D, p.visita, p.fecha);
    }
  });
  return { V, E, J, D, temporada: temporadas[temporadas.length - 1]?.temporada };
}

/* Diferencia 2 declarada arriba: los jugadores pasan a la temporada nueva
   con sus minutos y ritmo, pero valiendo pocos partidos, y sin fechas (el
   plantel de ±15 días se arma con la temporada nueva). */
export function arrastrarJugadores(J) {
  for (const x of J.jug.values()) {
    x.n = Math.min(x.n, ARRASTRE_JUGADORES.n);
    x.fechas = [];
  }
}

/* ─── el pronóstico de un partido ─────────────────────────────────────── */
/* `parte` = filas emparejadas del parte oficial (con jugadorId, equipoId,
   ausente). Devuelve todo lo que el navegador necesita. */
export function pronosticar(estado, partido, parte = [], equiposPorId = new Map(), jugadoresInfo = {}) {
  const { V, E, J, D } = estado;
  const F = fuerzasM0(E);
  const v = pronosticoVara(V, partido.local, partido.visita, VARA);
  const m0 = pronosticoM0(E, partido.local, partido.visita, F);
  const dL = diasDesde(D, partido.local, partido.fecha), dV = diasDesde(D, partido.visita, partido.fecha);
  const b2bL = dL <= 1 ? 1 : 0, b2bV = dV <= 1 ? 1 : 0;

  const lado = equipo => {
    const P = plantel(J, equipo, partido.fecha).map(x => ({ x, ...habitual(J, x) })).sort((a, b) => b.min - a.min);
    const delParte = new Map(parte.filter(f => f.jugadorId != null && (f.equipoId === equipo || f.equipoId == null)).map(f => [f.jugadorId, f]));
    const ausentes = new Set([...delParte.values()].filter(f => f.ausente).map(f => f.jugadorId));
    const todos = P.map(h => h.x);
    const disponibles = new Set(todos.map(x => x.j).filter(j => !ausentes.has(j)));
    const prodLleno = produccion(todos, J);
    const prodParte = produccion(todos, J, disponibles);
    /* el peso de cada uno: cuánto cae la producción si además falta él */
    const jugadores = P.map(h => {
      const sin = new Set(disponibles); sin.delete(h.x.j);
      const conEl = disponibles.has(h.x.j) ? prodParte : produccion(todos, J, new Set([...disponibles, h.x.j]));
      const sinEl = disponibles.has(h.x.j) ? produccion(todos, J, sin) : prodParte;
      const f = delParte.get(h.x.j);
      return { id: h.x.j, n: jugadoresInfo[h.x.j]?.n || String(h.x.j), pos: jugadoresInfo[h.x.j]?.p || "",
               min: +h.min.toFixed(1), ritmo: +h.ritmo.toFixed(3), partidos: h.x.n,
               estado: f ? f.estado : "", motivo: f ? f.motivo : "",
               ausente: ausentes.has(h.x.j),
               /* en puntos de margen, ya multiplicado por s */
               peso: +(M1.s * (conEl - sinEl)).toFixed(2) };
    });
    return { equipo, delta: prodLleno - prodParte, jugadores, prodLleno: +prodLleno.toFixed(1), prodParte: +prodParte.toFixed(1),
             ausentes: [...ausentes] };
  };
  const L = lado(partido.local), Vv = lado(partido.visita);
  const margen1 = m0.margen - M1.s * L.delta + M1.s * Vv.delta;
  const margen1d = margen1 + M1.b2b * (b2bV - b2bL);
  const eq = id => equiposPorId.get(id) || { id };
  return {
    id: partido.id, fecha: partido.fecha,
    local: { ...eq(partido.local), b2b: b2bL, descanso: dL, ...L },
    visita: { ...eq(partido.visita), b2b: b2bV, descanso: dV, ...Vv },
    vara: { margen: +v.margen.toFixed(2), p: +v.p.toFixed(3) },
    m0: { margen: +m0.margen.toFixed(2), p: +m0.p.toFixed(3), evaluable: m0.evaluable },
    m1: { margen: +margen1.toFixed(2), p: +Phi(margen1 / M0.desvio).toFixed(3) },
    m1d: { margen: +margen1d.toFixed(2), p: +Phi(margen1d / M0.desvio).toFixed(3) },
    /* lo que el navegador necesita para recalcular cualquier combinación */
    modelo: { s: M1.s, desvio: M0.desvio, b2b: M1.b2b, topeMinutos: M1.topeMinutos, reemplazo: +ritmoReemplazo(J).toFixed(3) },
  };
}

/* ─── la baja de la noche ─────────────────────────────────────────────── */
/* De todos los ausentes de los partidos publicados, el que más pesa: la
   historia del día ("Sin Jokić, Denver pasa de 75% a 61%"). Devuelve null
   si no hay ausentes con peso. `pCon` es la probabilidad del EQUIPO del
   jugador si jugara; `pSin`, la publicada (M1 + descanso). */
export function laBajaDe(partidos, minimo = 0.5) {
  let mejor = null;
  for (const p of partidos) {
    for (const [lado, eq, rival] of [["local", p.local, p.visita], ["visita", p.visita, p.local]]) {
      for (const j of eq.jugadores || []) {
        if (!j.ausente || !(j.peso > minimo)) continue;
        if (mejor && j.peso <= mejor.peso) continue;
        const signo = lado === "local" ? 1 : -1;
        const pSinLocal = p.m1d.p, mConLocal = p.m1d.margen + signo * j.peso;
        const pConLocal = Phi(mConLocal / p.modelo.desvio);
        mejor = { id: p.id, fecha: p.fecha, jugador: j.n, jugadorId: j.id, estado: j.estado, motivo: j.motivo,
                  equipo: eq.apodo || eq.codigo, codigo: eq.codigo, rival: rival.apodo || rival.codigo, rivalCodigo: rival.codigo, local: lado === "local",
                  peso: j.peso, pCon: +(lado === "local" ? pConLocal : 1 - pConLocal).toFixed(3), pSin: +(lado === "local" ? pSinLocal : 1 - pSinLocal).toFixed(3) };
      }
    }
  }
  return mejor;
}

/* ─── el registro: lo que dijimos, para contrastarlo después ──────────── */
/* `registro` = { [id]: { id, fecha, local, visita, p, margen, generado } }.
   Cada corrida pisa la fila del partido con el pronóstico más nuevo (el
   último antes del partido es el que vale) y tira lo de más de 60 días. */
export function actualizarRegistro(registro, partidos, generado, ahora = generado) {
  const R = { ...registro };
  for (const p of partidos) R[p.id] = { id: p.id, fecha: p.fecha, local: p.local.id, visita: p.visita.id, p: p.m1d.p, margen: p.m1d.margen, generado };
  const corte = +new Date(ahora) - 60 * DIA;
  for (const id of Object.keys(R)) if (+new Date(R[id].fecha) < corte) delete R[id];
  return R;
}

/* Los jugados de los últimos `dias` días con lo que el modelo había dicho.
   Puntito: verde si ganó el favorito; gris si ganó el otro pero daba parejo
   (favorito < 60% redondeado); naranja si fue sorpresa. */
export function jugadosDe(registro, T, ahora, dias = 3, equiposPorId = new Map()) {
  const t0 = +new Date(ahora) - dias * DIA, t1 = +new Date(ahora);
  const eq = id => equiposPorId.get(id) || { id };
  return (T.partidos || [])
    .filter(p => registro[p.id] && p.pl != null && p.pv != null && +new Date(p.fecha) >= t0 && +new Date(p.fecha) <= t1)
    .sort((a, b) => new Date(b.fecha) - new Date(a.fecha))
    .map(p => {
      const r = registro[p.id];
      const pFav = Math.max(r.p, 1 - r.p), favLocal = r.p >= 0.5, ganoLocal = p.pl > p.pv;
      const acerto = favLocal === ganoLocal;
      const punto = acerto ? "verde" : Math.round(pFav * 100) < 60 ? "gris" : "naranja";
      return { id: p.id, fecha: p.fecha, local: eq(p.local), visita: eq(p.visita), pl: p.pl, pv: p.pv, p: r.p, margen: r.margen, punto };
    });
}

/* Los partidos que se publican: los próximos dentro de la ventana. */
export function proximosDe(T, ahora, horas = HORAS_ADELANTE) {
  const t0 = +new Date(ahora), t1 = t0 + horas * 36e5;
  return (T.proximos || []).filter(p => { const t = +new Date(p.fecha); return t >= t0 - 6 * 36e5 && t <= t1; });
}

/* ─── cargar ──────────────────────────────────────────────────────────── */
/* Para el motor diario TODAS las temporadas son datos: las limpias ya se
   gastaron y ahora sirven para precalentar. Las parciales también (solo
   precalientan). */
export function cargarTodo(temporadaActual) {
  const T = new Map();
  for (const c of ["./datos-parciales/", "./datos-limpios/", "./datos/"]) {
    if (!existsSync(aca(c))) continue;
    for (const f of readdirSync(aca(c))) {
      const m = /^temporada-(\d{4})\.json$/.exec(f); if (!m) continue;
      T.set(+m[1], JSON.parse(readFileSync(new URL(f, aca(c)), "utf8")));   /* datos/ pisa a las demás */
    }
  }
  return [...T.entries()].filter(([y]) => y <= temporadaActual).sort((a, b) => a[0] - b[0]).map(([, S]) => S);
}

function arg(nombre, def) { const i = process.argv.indexOf("--" + nombre); return i > 0 ? process.argv[i + 1] : def; }

async function main() {
  const hasta = arg("hasta", null);
  const ahora = hasta ? new Date(hasta) : new Date();
  /* sin --temporada, la última que haya en el repo: la ingesta con
     "actual" deja la más nueva que la API tenga */
  const todas = cargarTodo(9999);
  const temporada = +arg("temporada", 0) || (todas.length ? todas[todas.length - 1].temporada : temporadaDe(ahora));
  const S = cargarTodo(temporada);
  if (!S.length || S[S.length - 1].temporada !== temporada) { console.log(`No está datos/temporada-${temporada}.json: corré la ingesta primero.`); process.exit(1); }
  /* las dos últimas alcanzan: la anterior precalienta, la actual es la viva */
  const usadas = S.slice(-2);
  const actual = usadas[usadas.length - 1];
  const estado = armarEstado(usadas, hasta);
  const equiposPorId = new Map(actual.equipos.map(e => [e.id, { id: e.id, nombre: e.nombre, apodo: e.apodo, codigo: e.codigo }]));

  let parte = { filas: [] }, emparejadas = { ok: [], sinPareja: [] };
  if (existsSync(aca("./partes/ultimo.json"))) {
    parte = JSON.parse(readFileSync(aca("./partes/ultimo.json"), "utf8"));
    emparejadas = emparejar(parte.filas || [], actual.jugadores, actual.equipos);
    console.log(`  parte ${parte.fecha || "—"} ${parte.hora || ""}: ${emparejadas.ok.length} emparejados, ${emparejadas.sinPareja.length} sin pareja` +
      (emparejadas.sinPareja.length ? " (" + emparejadas.sinPareja.slice(0, 8).map(f => f.jugador).join(", ") + ")" : ""));
  } else console.log("  sin parte de lesionados: todos disponibles");

  /* con --hasta, los "próximos" son los partidos reales que siguen al corte */
  const proximos = hasta
    ? actual.partidos.filter(p => +new Date(p.fecha) >= +ahora).slice(0, 15).map(p => ({ id: p.id, fecha: p.fecha, local: p.local, visita: p.visita }))
    : proximosDe(actual, ahora);
  const salida = {
    temporada, generado: new Date().toISOString(), parte: { fecha: parte.fecha || null, hora: parte.hora || null, url: parte.url || null,
      sinPareja: emparejadas.sinPareja.map(f => ({ jugador: f.jugador, equipo: f.equipo, estado: f.estado })) },
    partidos: proximos.map(p => pronosticar(estado, p, emparejadas.ok, equiposPorId, actual.jugadores)),
  };
  salida.baja = laBajaDe(salida.partidos);
  mkdirSync(aca("./docs/datos/"), { recursive: true });
  /* el registro de lo dicho y los jugados con lo que se dijo */
  const rutaRegistro = aca("./docs/datos/nba-registro.json");
  const registroViejo = existsSync(rutaRegistro) ? JSON.parse(readFileSync(rutaRegistro, "utf8")) : {};
  const registro = actualizarRegistro(registroViejo, salida.partidos, salida.generado, ahora);
  writeFileSync(rutaRegistro, JSON.stringify(registro));
  const jugados = { temporada, generado: salida.generado, partidos: jugadosDe(registro, actual, ahora, 3, equiposPorId) };
  writeFileSync(aca("./docs/datos/nba-jugados.json"), JSON.stringify(jugados));
  writeFileSync(aca("./docs/datos/nba-jugados.js"), "window.NBA_JUGADOS=" + JSON.stringify(jugados) + ";\n");
  console.log(`  registro: ${Object.keys(registro).length} pronósticos guardados; jugados de 3 días: ${jugados.partidos.length}` + (salida.baja ? `; la baja: ${salida.baja.jugador} (${salida.baja.codigo}) ${salida.baja.peso}` : "; sin baja que pese"));
  writeFileSync(aca("./docs/datos/nba-hoy.json"), JSON.stringify(salida));
  writeFileSync(aca("./docs/datos/nba-hoy.js"), "window.NBA_HOY=" + JSON.stringify(salida) + ";\n");
  console.log(`  ${salida.partidos.length} partidos pronosticados`);
  for (const p of salida.partidos) {
    const aus = [...p.local.jugadores, ...p.visita.jugadores].filter(j => j.ausente).map(j => j.n);
    console.log(`    ${p.fecha.slice(0, 10)}  ${p.visita.codigo || p.visita.id} @ ${p.local.codigo || p.local.id}  M0 ${p.m0.margen > 0 ? "+" : ""}${p.m0.margen} (${(p.m0.p * 100).toFixed(0)}%)  M1 ${p.m1.margen > 0 ? "+" : ""}${p.m1.margen} (${(p.m1.p * 100).toFixed(0)}%)` +
      (aus.length ? "  sin " + aus.join(", ") : ""));
  }
}
/* La temporada de la API: 2026 = 2026-27. Empieza en octubre; de julio a
   septiembre "en curso" es la que viene. */
export const temporadaDe = d => d.getUTCMonth() >= 6 ? d.getUTCFullYear() : d.getUTCFullYear() - 1;

if (process.argv[1] && import.meta.url.endsWith(process.argv[1].split(/[\\/]/).pop())) await main();
