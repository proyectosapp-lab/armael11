/* PROBAR-QUINTETO — pruebas de la app (sitio/ o docs/) leyendo los
   archivos como texto y corriendo la cuenta de la pantalla en Node.
     node probar-quinteto.mjs            (mira docs/; con --sitio mira sitio/) */
import { readFileSync, existsSync } from "node:fs";
const carpeta = process.argv.includes("--sitio") ? "./sitio/" : "./docs/";
const aca = p => new URL(carpeta + p, import.meta.url);
const leer = p => readFileSync(aca(p), "utf8");
const casos = []; const caso = (n, ok, d) => casos.push([n, !!ok, d]);

const html = leer("index.html"), js = leer("quinteto.js"), css = leer("quinteto.css"), cuentas = leer("quinteto-cuentas.js"), sitio = leer("sitio.js");
const todo = html + js + css + cuentas + leer("gracias.html") + leer("privacidad.html");

/* ── lo que no puede estar ── */
const PROHIBIDAS = [/\bcuotas? (de|para)\b/i, /\bpick\b/i, /\bfija\b/i, /(?<![.\w])value\b(?!=)/i, /\bacert[áa]\b/i, /ganale a la casa/i, /\beficacia\b/i, /\bapost[aá]/i];
caso("ninguna palabra prohibida en toda la app", !PROHIBIDAS.some(r => r.test(todo.replace(/sin cuotas|0 cuotas|cuotas ni|cuotas\. /gi, "").replace(/publicidad de apuestas|apuestas\./gi, ""))), PROHIBIDAS.filter(r => r.test(todo)).map(String).join(" "));
caso("\"sin cuotas\" y \"app independiente\" están dichos", /sin cuotas/i.test(html) && /app independiente/i.test(html));
caso("ningún precio en el cliente: lo pone el servidor", !/\b2\.?990\b|\bprecio: *\d/.test(js + cuentas + html));
caso("ninguna clave secreta ni token en los archivos", !/service_role|sk_live|eyJ[a-zA-Z0-9_-]{30,}/.test(todo + sitio));
caso("sin escudos ni fotos de terceros: monogramas", !/nba\.com\/.*\.(png|svg)|cdn\.nba|logos?\//i.test(todo));
caso("no dice starting5 en ningún lado", !/starting ?5/i.test(todo));

/* ── la estructura ── */
caso("el html carga los datos, la cuenta y la app en ese orden", html.indexOf("sitio.js") < html.indexOf("nba-hoy.js") && html.indexOf("nba-hoy.js") < html.indexOf("quinteto-cuentas.js") && html.indexOf("quinteto-cuentas.js") < html.indexOf("quinteto.js"));
caso("las cuatro pantallas: hoy, jugados, medido, ajustes", ["sec-hoy", "sec-jugados", "sec-medido", "sec-ajustes"].every(id => html.includes('id="' + id + '"')));
caso("la puerta es un partido ya cargado (no un selector)", html.includes('id="q5-puerta"') && !/<select[^>]*id="q5-partido/.test(html));
caso("la baja de la noche tiene su lugar y se comparte", html.includes('id="q5-baja"') && /Compartir/.test(js));
caso("todo lo del script de primer nivel empieza con q5 (ámbito global compartido)", !/^  (var|function)\s+(?!q5|Q5|\$ )[A-Za-z_$]/m.test(js));
caso("Poppins y los colores de la familia", /Poppins/.test(css) && /#F6F1EA/i.test(css) && /#14110F/i.test(css) && /#0D1117/i.test(css) && /#E8731C/i.test(css));
caso("tema papel/noche/auto", /data-tema="noche"/.test(css) && /prefers-color-scheme: dark/.test(css) && /data-tema="auto"/.test(html));
caso("la regla de presentación: banda −1 a +0,5 → ≈ 0", /desde: -1, hasta: 0\.5/.test(js) && /≈ 0/.test(js));
caso("hora de Argentina", /America\/Argentina\/Buenos_Aires/.test(js));
caso("el candado: probalo gratis sin cuenta, terminó tu prueba, sacar el pase", /Probalo " \+ q5acceso\.diasPrueba \+ " días gratis/.test(js) && /Terminó tu prueba gratis/.test(js) && /Sacar el pase/.test(js));
caso("el botón de la cuenta cambia: Probar gratis / Prueba · / Con el pase / Sacar el pase", ["Probar gratis", "Prueba · ", "Con el pase", "Sacar el pase"].every(t => js.includes(t)));
caso("la cuenta es la misma llave de sesión de la familia (tste.sesion) y el perfil no se pisa", /tste\.sesion/.test(cuentas) && /ignore-duplicates/.test(cuentas));
caso("el acceso lo decide el servidor: cobra_quinteto, pase, mi_prueba_quinteto", /cobra_/.test(cuentas) && /\/rest\/v1\/pase/.test(cuentas) && /mi_prueba_/.test(cuentas));
caso("sin claves en sitio.js → modo abierto", /configurado = !!\(url && anon\)/.test(cuentas) && /sin-configurar/.test(cuentas));
caso("gracias.html no le cree al estado de la dirección", /No se le cree/.test(leer("gracias.html")) && !/\bstatus\b|\bapproved\b/.test(leer("gracias.html")));
caso("el manifest y los íconos existen", existsSync(aca("manifest.webmanifest")) && existsSync(aca("icono-192.png")) && existsSync(aca("icono-512.png")) && existsSync(aca("apple-touch-icon.png")) && existsSync(aca("og.png")));
caso("nba.html manda a la puerta nueva", /url=\.\//.test(leer("nba.html")));

/* ── la cuenta de la pantalla, corrida de verdad ── */
{
  const fake = { document: null };
  const src = js.match(/function q5Phi[\s\S]*?\n  \}\n/)[0] + js.match(/function q5PesoVisible[^\n]*\n/)[0] + js.match(/function q5Estado[\s\S]*?return \{ fuera: fuera \};\n  \}\n/)[0] + js.match(/function q5Calcular[\s\S]*?pBase: q5Phi\(base \/ p\.modelo\.desvio\) \};\n  \}\n/)[0];
  const f = new Function("Q5_BANDA", src + "return { q5Calcular, q5Estado, q5PesoVisible, q5Phi };")({ desde: -1, hasta: 0.5 });
  const p = { m0: { margen: 2 }, modelo: { b2b: 2, desvio: 12.5 }, local: { b2b: 0, jugadores: [{ id: 1, peso: 3, ausente: false }, { id: 2, peso: -0.6, ausente: false }] }, visita: { b2b: 1, jugadores: [{ id: 3, peso: 2, ausente: true }] } };
  const est = f.q5Estado(p); const c = f.q5Calcular(p, est);
  caso("la cuenta: base = M0 + b2b, más el ausente del parte", Math.abs(c.base - 4) < 1e-9 && Math.abs(c.margen - 6) < 1e-9);
  est.fuera[1] = true; est.fuera[2] = true;
  const c2 = f.q5Calcular(p, est);
  caso("sacar a la estrella local resta su peso; el de la banda cuenta 0", Math.abs(c2.margen - 3) < 1e-9);
  caso("Φ(0) = 0,5 y la probabilidad sube con el margen", Math.abs(f.q5Phi(0) - 0.5) < 1e-6 && c.p > c2.p);
  caso("≈ 0: −0,6 → 0; 0,7 → 0,7; −1,2 → −1,2", f.q5PesoVisible(-0.6) === 0 && f.q5PesoVisible(0.7) === 0.7 && f.q5PesoVisible(-1.2) === -1.2);
}

const raya = "─".repeat(70);
console.log("\n" + raya);
casos.forEach(([n, ok, d]) => console.log("  " + (ok ? "ok    " : "MAL   ") + n + (d && !ok ? "   → " + d : "")));
const mal = casos.filter(c => !c[1]).length;
console.log(raya + "\n\n" + (mal ? mal + " de " + casos.length + " MAL\n" : casos.length + " de " + casos.length + ". Todo bien.\n"));
process.exit(mal ? 1 : 0);
