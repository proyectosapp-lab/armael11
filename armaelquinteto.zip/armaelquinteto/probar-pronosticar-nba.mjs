/* ══════════════════════════════════════════════════════════════════════════
   PRUEBA DEL MOTOR DIARIO
     node probar-pronosticar-nba.mjs
   Sin red. Verifica que el motor use el mismo modelo que el backtest, que
   el parte mueva el pronóstico para el lado correcto, que el arrastre de
   jugadores entre temporadas haga lo que dice, y que el corte `hasta` no
   deje pasar el futuro.
   ══════════════════════════════════════════════════════════════════════════ */
import { laBajaDe, actualizarRegistro, jugadosDe, armarEstado, pronosticar, arrastrarJugadores, proximosDe, temporadaDe, ARRASTRE_JUGADORES } from "./pronosticar-nba.mjs";
import { m1Nuevo, sumarM1, pronosticoM0, fuerzasM0, M1, Phi } from "./backtest-nba.mjs";

const casos = [];
const caso = (n, ok, d = "") => casos.push([n, ok, d]);
const cerca = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol;

/* una temporada chica: 6 equipos, 10 jugadores cada uno, 60 días */
const dia = d => new Date(Date.UTC(2022, 9, 20) + d * 864e5).toISOString();
const linea = (j, eq, min, pts) => [j, eq, min, pts, Math.round(pts / 2.5), Math.round(pts / 1.2), 1, 3, 1, 2, 1, 3, 2, 1, 0, 1, 2, 0, 0];
function temporadaInventada(anio, fuerza) {
  const partidos = []; let id = anio * 1000;
  for (let d = 0; d < 60; d++) for (let i = 0; i < 6; i += 2) {
    const l = ((i + d) % 6) + 1, v = ((i + d + 1) % 6) + 1;
    const margen = 3 + fuerza[l] - fuerza[v] + ((d * 7 + i) % 11 - 5);
    const pl = 105 + Math.round(margen / 2), pv = 105 - Math.round(margen / 2);
    const lineas = [];
    for (const [eq, pts] of [[l, pl], [v, pv]]) {
      const mins = [36, 34, 32, 30, 28, 24, 20, 16, 12, 8];
      mins.forEach((m, k) => lineas.push(linea(eq * 100 + k, eq, m, Math.round(pts * m / 240 * (k === 0 ? 1.6 : 0.93)))));
    }
    partidos.push({ id: id++, fecha: dia(d), etapa: "regular", local: l, visita: v, pl, pv, periodos: 4, lineas });
  }
  return { temporada: anio, partidos, proximos: [{ id: 99990, fecha: dia(60), local: 1, visita: 2 }, { id: 99991, fecha: dia(63), local: 3, visita: 4 }],
           equipos: [1, 2, 3, 4, 5, 6].map(i => ({ id: i, codigo: "E" + i, nombre: "Equipo " + i })), jugadores: {} };
}
const fuerza = { 1: 6, 2: 3, 3: 0, 4: 0, 5: -3, 6: -6 };
const T21 = temporadaInventada(2021, fuerza), T22 = temporadaInventada(2022, fuerza);
const equiposPorId = new Map(T22.equipos.map(e => [e.id, e]));

/* ─── el estado ────────────────────────────────────────────────────────── */
{
  const est = armarEstado([T21, T22]);
  const F = fuerzasM0(est.E);
  caso("M0 ordena los equipos por fuerza", F.get(1) > F.get(2) && F.get(2) > F.get(3) && F.get(5) > F.get(6), [1, 2, 3, 6].map(i => F.get(i).toFixed(1)).join(" "));
  caso("los jugadores traen 5 de arrastre más los 60 de la temporada en curso", est.J.jug.get("100:1").n === 65, String(est.J.jug.get("100:1").n));
  const est2 = armarEstado([T21, T22], dia(30));
  caso("con corte, solo entran los partidos anteriores (5 + 30)", est2.J.jug.get("100:1").n === 35 && est2.E.eq.get(1).n === 30);
}

/* ─── el arrastre de jugadores ─────────────────────────────────────────── */
{
  const J = m1Nuevo(M1);
  for (const p of T21.partidos) sumarM1(J, p);
  const antes = J.jug.get("100:1");
  const minAntes = antes.min, ritmoAntes = antes.ritmo;
  arrastrarJugadores(J);
  caso("al cambiar de temporada conserva minutos y ritmo pero vale pocos partidos y sin fechas",
       antes.n === ARRASTRE_JUGADORES.n && antes.min === minAntes && antes.ritmo === ritmoAntes && antes.fechas.length === 0);
}

/* ─── el pronóstico y el parte ─────────────────────────────────────────── */
{
  const est = armarEstado([T21, T22]);
  const partido = { id: 99990, fecha: dia(60), local: 1, visita: 2 };
  const sinParte = pronosticar(est, partido, [], equiposPorId, {});
  caso("sin parte, M1 = M0 (nadie ausente)", cerca(sinParte.m1.margen, sinParte.m0.margen, 0.011) && sinParte.local.ausentes.length === 0);
  caso("el local es el más fuerte: margen positivo y p > 0,5", sinParte.m0.margen > 0 && sinParte.m0.p > 0.5);
  caso("el plantel trae a los 10 con minutos, ritmo y peso", sinParte.local.jugadores.length === 10 && sinParte.local.jugadores[0].min > 30 && typeof sinParte.local.jugadores[0].peso === "number");
  caso("la estrella pesa más que el décimo", sinParte.local.jugadores[0].peso > sinParte.local.jugadores[9].peso);
  caso("el modelo publica s, desvío, b2b, tope y reemplazo para el navegador",
       sinParte.modelo.s === M1.s && sinParte.modelo.reemplazo > 0 && sinParte.modelo.topeMinutos === 40);
  /* la estrella del local (100) está Out */
  const parte = [{ jugadorId: 100, equipoId: 1, estado: "Out", motivo: "Injury/Illness - Left Knee; Soreness", ausente: true }];
  const conParte = pronosticar(est, partido, parte, equiposPorId, {});
  caso("con la estrella local Out, el margen baja", conParte.m1.margen < sinParte.m1.margen, conParte.m1.margen + " < " + sinParte.m1.margen);
  caso("y baja exactamente su peso (s × producción perdida)", cerca(sinParte.m1.margen - conParte.m1.margen, sinParte.local.jugadores.find(j => j.id === 100).peso, 0.02));
  caso("el jugador sale marcado con estado y motivo", conParte.local.jugadores.find(j => j.id === 100).ausente && conParte.local.jugadores.find(j => j.id === 100).estado === "Out");
  caso("M0 no cambia con el parte", cerca(conParte.m0.margen, sinParte.m0.margen));
  /* Questionable no es ausente pero queda marcado */
  const q = pronosticar(est, partido, [{ jugadorId: 100, equipoId: 1, estado: "Questionable", motivo: "Rest", ausente: false }], equiposPorId, {});
  caso("Questionable: presente y marcado", !q.local.jugadores.find(j => j.id === 100).ausente && q.local.jugadores.find(j => j.id === 100).estado === "Questionable" && cerca(q.m1.margen, sinParte.m1.margen, 0.011));
  /* un ausente del visitante sube el margen */
  const v = pronosticar(est, partido, [{ jugadorId: 200, equipoId: 2, estado: "Doubtful", motivo: "x", ausente: true }], equiposPorId, {});
  caso("con la estrella visitante Doubtful, el margen sube", v.m1.margen > sinParte.m1.margen);
}

/* ─── próximos y temporada ─────────────────────────────────────────────── */
caso("próximos: dentro de 48 horas desde 'ahora'", proximosDe(T22, dia(59)).length === 1 && proximosDe(T22, dia(59), 120).length === 2);
caso("temporada de la API: septiembre 2026 → 2026, marzo 2027 → 2026, junio 2026 → 2025",
     temporadaDe(new Date("2026-09-22")) === 2026 && temporadaDe(new Date("2027-03-01")) === 2026 && temporadaDe(new Date("2026-06-10")) === 2025);

/* ─── la baja, el registro y los jugados ──────────────────────────────── */
{
  const mk = (id, fecha, jug) => ({ id, fecha, local: { id: 1, codigo: "AAA", apodo: "Aes", jugadores: jug.l || [] }, visita: { id: 2, codigo: "BBB", apodo: "Bes", jugadores: jug.v || [] },
    m1d: { margen: 3, p: 0.595 }, modelo: { desvio: 12.5 } });
  const ps = [
    mk(1, "2026-11-01T00:00:00Z", { l: [{ id: 9, n: "Estrella", peso: 4, ausente: true, estado: "Out", motivo: "x" }, { id: 8, n: "Chico", peso: 0.3, ausente: true }] }),
    mk(2, "2026-11-01T02:00:00Z", { v: [{ id: 7, n: "Visitante", peso: 5.5, ausente: true, estado: "Out", motivo: "y" }, { id: 6, n: "Presente", peso: 9, ausente: false }] }),
  ];
  const baja = laBajaDe(ps);
  caso("la baja de la noche es el ausente que más pesa, no el presente", baja && baja.jugador === "Visitante" && baja.peso === 5.5);
  caso("la baja del visitante: pSin < pCon, y son las del visitante", baja.pSin < baja.pCon && cerca(baja.pSin, 1 - 0.595, 0.001) && cerca(baja.pCon, 1 - Phi((3 - 5.5) / 12.5), 0.001));
  caso("sin ausentes que pesen → null", laBajaDe([mk(3, "2026-11-01T00:00:00Z", { l: [{ id: 1, n: "a", peso: 0.2, ausente: true }] })]) === null);
  const R1 = actualizarRegistro({}, ps, "2026-10-31T12:00:00Z");
  caso("el registro guarda un pronóstico por partido", Object.keys(R1).length === 2 && R1[1].p === 0.595 && R1[2].local === 1);
  const R2 = actualizarRegistro({ ...R1, 99: { id: 99, fecha: "2026-06-01T00:00:00Z", p: 0.5 } }, [{ ...ps[0], m1d: { margen: 1, p: 0.53 } }], "2026-10-31T18:00:00Z");
  caso("la corrida nueva pisa el pronóstico viejo y tira lo de hace 60 días", R2[1].p === 0.53 && !R2[99] && R2[2]);
  const T = { partidos: [
    { id: 1, fecha: "2026-11-01T00:00:00Z", local: 1, visita: 2, pl: 110, pv: 100 },
    { id: 2, fecha: "2026-11-01T02:00:00Z", local: 1, visita: 2, pl: 90, pv: 100 },
    { id: 5, fecha: "2026-10-20T02:00:00Z", local: 1, visita: 2, pl: 90, pv: 100 },
    { id: 6, fecha: "2026-11-01T03:00:00Z", local: 1, visita: 2, pl: null, pv: null } ] };
  const J = jugadosDe({ 1: R2[1], 2: { ...R2[2], p: 0.71 }, 5: { p: 0.6, margen: 3 }, 6: { p: 0.5 } }, T, "2026-11-02T12:00:00Z", 3);
  caso("jugados: solo los de los últimos 3 días con resultado y pronóstico", J.length === 2 && J[0].id === 2);
  caso("puntitos: verde si ganó el favorito, naranja si fue sorpresa (≥60%)", J[1].punto === "verde" && J[0].punto === "naranja");
  caso("puntito gris cuando daba parejo", jugadosDe({ 2: { p: 0.55, margen: 1 } }, T, "2026-11-02T12:00:00Z", 3)[0].punto === "gris");
}

const raya = "─".repeat(70);
console.log("\n" + raya);
casos.forEach(([n, ok, d]) => console.log("  " + (ok ? "ok    " : "MAL   ") + n + (d ? "   → " + d : "")));
const mal = casos.filter(c => !c[1]).length;
console.log(raya + "\n\n" + (mal ? mal + " de " + casos.length + " MAL\n" : casos.length + " de " + casos.length + ". Todo bien.\n"));
process.exit(mal ? 1 : 0);
