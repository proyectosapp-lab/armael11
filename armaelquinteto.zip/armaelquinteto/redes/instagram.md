# Armá el Quinteto en Instagram

## La cuenta

- Usuario: **@armaelquinteto** (si está tomado, `@armaelquinteto.ok`, como
  `@sacavos.ok`). Nombre: Armá el Quinteto. Avatar: `marca/salida/avatar-instagram.png`.
- Bio (150 letras):
  > Sacá un jugador y mirá cuánto se mueve el partido. NBA, todos los días,
  > con el parte de lesionados. App independiente. Sin cuotas.
- Link: armaelquinteto.com
- Categoría: App. Sin botón de contacto por ahora.

## El gancho: la baja de la noche

Un posteo por día, a las 10 de la mañana de Argentina, con la baja que más
pesa: *"Sin Jokić, Denver pasa de 75% a 61%"*. Es la frase que nadie más
dice con un número, y sale sola del motor. El motor deja todo listo dos
veces por día en `redes/hoy/`:

| archivo | para qué |
|---|---|
| `baja.png` | el posteo del feed (1080×1350) |
| `baja-historia.png` | la historia (1080×1920), con el link a la app |
| `partidos.png` | los partidos del día con su barra; segundo posteo o carrusel |
| `textos.md` | los pies de foto, para copiar y pegar |

Cuando no hay una baja que pese (menos de 0,5 puntos), no se postea la
baja: se postea la lista de partidos sola. Nunca se inventa una.

Rutina de Fausto (5 minutos): abrir `redes/hoy/` en GitHub, bajar las
imágenes, copiar el texto, postear feed + historia. Contestar comentarios
con números, nunca con "va a ganar".

## Las reglas

- Voz de la familia: de vos, corta, sin exclamaciones, sin emojis, sin
  superlativos. Cuando hay un número, va el número.
- Prohibidas: cuota, pick, fija, value, acertá, ganale a la casa. Nada de
  "eficacia". Nunca "va a ganar": siempre "pasa de X% a Y%".
- Todo posteo cierra con "App independiente. Sin cuotas." Sin logos ni
  fotos de la NBA ni de jugadores: monogramas y texto.
- Al otro día, si la baja fue sorpresa, se dice igual ("daba Nets 61%,
  ganó Milwaukee sin Giannis"): los jugados son parte del producto.

## Los tres primeros posteos (`redes/lanzamiento/`)

**1 · Presentación** (`1-presentacion.png`)
> Armá el Quinteto: los partidos de la NBA de esta noche con el parte de
> lesionados oficial aplicado. Sacá un jugador y mirá cuánto se mueve el
> partido. Un interruptor por jugador; el número, siempre.
>
> Es de la misma familia que Armá el 11 (fútbol) y Sacá vos (tenis).
> App independiente. Sin cuotas. Link en la bio.
> #NBA #ArmáElQuinteto

**2 · Está medido** (`2-esta-medido.png`)
> Cuando dice 70%, pasa el 69%. El modelo se armó con 7.199 partidos
> (2016 a 2023) y se probó una sola vez sobre 2.151 que nunca había visto:
> acierta el ganador el 68%. "El de mejor récord gana" acierta el 65%.
>
> Lo que vende la app es otra cosa: cuando falta un titular, mover el
> pronóstico por esa baja mejora el acierto de forma medible. No
> prometemos aciertos: mostramos cuánto pesa cada jugador.
> App independiente. Sin cuotas.
> #NBA #ArmáElQuinteto

**3 · La baja de la noche** (`3-la-baja.png`; el ejemplo es de la
temporada 2022-23, replayado)
> Así se ve todos los días: sin Antetokounmpo, Bucks pasa de 50% a 39%.
> Son 3,4 puntos de margen: sus minutos habituales por lo que produce por
> minuto, menos lo que produce el que entra por él.
>
> Desde el primer partido de la temporada, la baja de la noche todas las
> mañanas a las 10. Y en la app la sacás y la ponés vos.
> App independiente. Sin cuotas.
> #NBA #ArmáElQuinteto

## Después del lanzamiento

- Semana 1: los tres posteos, uno por día. Después, la baja diaria.
- Cuando haya 30 jugados: el primer "así nos fue" (la tabla de calibración
  de la temporada, `Está medido` en la app).
- Campañas pagas: igual que Armá el 11 (`claude/campana-instagram.md`),
  con el posteo de la baja como anuncio, recién cuando el cobro esté
  prendido.
