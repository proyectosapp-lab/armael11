# Instagram · martes 28

## Los partidos (partidos.png)

Los partidos de hoy, con el parte de lesionados aplicado:

WAS @ ATL · 21:30 · Hawks 51%
MIL @ BKN · 21:30 · Nets 61%
CHI @ TOR · 21:30 · Raptors 57%
LAL @ MEM · 21:30 · Grizzlies 72%
DEN @ HOU · 22:00 · Nuggets 75%
SAC @ OKC · 22:00 · Thunder 55%
IND @ DAL · 22:30 · Mavericks 62%
SAS @ UTA · 23:00 · Jazz 82%

La baja que más pesa: Giannis Antetokounmpo (MIL), -3,4 puntos.

Hora argentina. Sacá o poné jugadores en la app: link en la bio.

App independiente. Sin cuotas.
#NBA #ArmáElQuinteto

## La baja de la noche (baja.png · baja-historia.png)

Sin Antetokounmpo, Bucks pasa de 50% a 39%.

Giannis Antetokounmpo no juega (der. tobillo, esguince). Bucks visita a Nets a las 21:30. Son 3,4 puntos de margen: sus minutos habituales por lo que produce por minuto, menos lo que produce el que entra por él.

En la app podés sacarlo y ponerlo, y ver cuánto se mueve. Link en la bio.

App independiente. Sin cuotas.
#NBA #MIL #ArmáElQuinteto
