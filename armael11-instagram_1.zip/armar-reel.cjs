/* Arma el reel "¿Seguís tirando un dado?" a partir de:
     - los 62 cuadros del dado (ig/dadofr)
     - la grabación de la app de verdad (ig/grab/*.webm) + ig/grab/marcas.json
     - la loseta del 11 (ig/cuadro-cierre-9x16.png)
   Cortes secos, sin voz ni subtítulos: eso va en CapCut.
     node ig/armar-reel.cjs */
const { execFileSync } = require('child_process');
const fs = require('fs'), path = require('path');

const IG = '/home/claude/tste/ig';
const TMP = '/tmp/claude-0/-home-claude/46e59ecb-2ff1-57e5-8869-08fd5ca59065/scratchpad/reel';
const SALIDA = path.join(IG, 'reel-dado-sin-voz.mp4');
const FPS = 30, W = 1080, H = 1920;

const ff = a => execFileSync('ffmpeg', ['-v', 'error', '-y', ...a], { stdio: ['ignore', 'pipe', 'pipe'] });
const dur = f => parseFloat(execFileSync('ffprobe',
  ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]).toString());

fs.rmSync(TMP, { recursive: true, force: true });
fs.mkdirSync(TMP, { recursive: true });

/* ── el desfasaje ────────────────────────────────────────────────────────
   El video empieza a grabarse cuando se abre la pestaña, y el cronómetro
   del guion arranca después de que cargó la página. La diferencia se
   calcula, no se adivina: duración del video menos lo que duró el guion. */
const grab = path.join(IG, 'grab');
/* Se corta sobre el intermedio, no sobre el webm: en el webm ffmpeg salta al
   cuadro clave mas cercano y los planos se corren casi dos segundos. */
const webm = path.join(grab, 'intermedio.mp4');
const M = JSON.parse(fs.readFileSync(path.join(grab, 'marcas.json')));
const marca = n => M.marcas.find(m => m.n === n).ms / 1000;
const finGuion = M.marcas[M.marcas.length - 1].ms / 1000 + 2.8;
const OFF = dur(webm) - finGuion;

/* ── los planos, en segundos del guion ───────────────────────────────── */
/* La ventana de cada plano se eligio mirando los cuadros: los chips solo
   quedan a la vista un segundo y medio despues de tocarlos, porque al
   dibujarse de nuevo la fila vuelve al principio. */
const PLANOS = [
  ['once',      marca('once') + 0.35, 1.15],
  ['sim1',      marca('res1') + 0.25, 1.50],
  ['atras',     marca('chip-atras') - 0.30, 1.70],
  ['sim2',      marca('res2') + 0.25, 1.50],
  ['lavida',    marca('chip-lavida') - 0.30, 1.60],
  ['sim3',      marca('res3') + 0.25, 1.60],
  ['nocambio',  marca('no-cambiaste') + 0.15, 1.80],
];

const partes = [];

/* 1. el dado */
ff(['-framerate', 24, '-i', path.join(IG, 'dadofr/%03d.png'),
    '-vf', `fps=${FPS},scale=${W}:${H},setsar=1,format=yuv420p`,
    '-c:v', 'libx264', '-profile:v', 'high', '-crf', 18, '-preset', 'medium',
    path.join(TMP, '00-dado.mp4')]);
partes.push('00-dado.mp4');

/* 2. los planos de la app */
PLANOS.forEach(([n, t, d], i) => {
  const f = `${String(i + 1).padStart(2, '0')}-${n}.mp4`;
  /* el último se acerca un poco: el cartel queda arriba porque la página ya
     no puede bajar más, y de lejos no se lee */
  const filtro = n === 'nocambio'
    ? `crop=810:1440:135:70,scale=${W}:${H},setsar=1,fps=${FPS},format=yuv420p`
    : `fps=${FPS},scale=${W}:${H},setsar=1,format=yuv420p`;
  ff(['-ss', (t + OFF).toFixed(2), '-t', d, '-i', webm, '-vf', filtro,
      '-c:v', 'libx264', '-profile:v', 'high', '-crf', 18, '-preset', 'medium',
      path.join(TMP, f)]);
  partes.push(f);
});

/* 3. la loseta. Corte seco como todo el resto: el fundido pasaba por negro
   y cortaba el ritmo justo en el cierre. */
ff(['-loop', 1, '-t', 2.0, '-i', path.join(IG, 'cuadro-cierre-9x16.png'),
    '-vf', `scale=${W}:${H},setsar=1,fps=${FPS},format=yuv420p`,
    '-c:v', 'libx264', '-profile:v', 'high', '-crf', 18, '-preset', 'medium',
    path.join(TMP, '90-loseta.mp4')]);
partes.push('90-loseta.mp4');

/* 4. pegar todo, con una pista muda (CapCut y las redes la prefieren) */
fs.writeFileSync(path.join(TMP, 'lista.txt'), partes.map(p => `file '${p}'`).join('\n'));
ff(['-f', 'concat', '-safe', 0, '-i', path.join(TMP, 'lista.txt'),
    '-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
    '-shortest', '-c:v', 'libx264', '-profile:v', 'high', '-level', '4.0',
    '-pix_fmt', 'yuv420p', '-crf', 20, '-preset', 'medium',
    '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', SALIDA]);

const t = dur(SALIDA);
console.log(`desfasaje medido: ${OFF.toFixed(2)}s`);
console.log(partes.map(p => '  ' + p.padEnd(16) + dur(path.join(TMP, p)).toFixed(2) + 's').join('\n'));
console.log(`\n${path.basename(SALIDA)}  ${t.toFixed(2)}s`);
