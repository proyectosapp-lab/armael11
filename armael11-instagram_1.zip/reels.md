# Dos reels — guion, plano a plano

Los dos se hacen con **grabación de pantalla de la app** (Android: grabador de pantalla del sistema, 1080×1920, sin el audio del teléfono) y se editan en CapCut o en el editor de Reels. No hace falta filmar nada. Los planos de "manos con el teléfono" son opcionales: si los hacés, que sean con el teléfono en vertical, luz de ventana, y sin que se vea ninguna camiseta con escudo.

Vertical 9:16. Texto grande en la mitad superior (la barra de Reels tapa el tercio de abajo). Poppins Bold blanca con sombra, o la fuente "Moderna" del editor. Sin música con letra: una base rítmica seca, y el sonido del reel es la voz.

La regla de los dos: **nunca mostrar dos simulaciones seguidas con distinto resultado sin explicar por qué cambió.** Eso es exactamente la impresión de dado que costó arreglar (y31).

---

## Reel 1 — "¿Seguís tirando un dado?" (15 segundos) · YA ARMADO

**`reel-dado-sin-voz.mp4`** está hecho: 1080×1920, cortes secos, sin voz ni
subtítulos, con una pista de audio muda para que CapCut y las redes no se
quejen. No hay que filmar ni generar nada.

**De dónde salió cada cosa.** El dado NO es de Seedance: está dibujado y
animado acá (`dado.html` + `render-dado.cjs`), así que cae siempre igual, no
inventa dos dados ni le pone signos de pesos. La app no es una imitación: es
**la app de verdad**, grabada corriendo (`grabar-app.cjs`), con los datos
reales de Boca que bajó la corrida. Los números no los escribió nadie: son los
que dio el motor. El cierre es la misma loseta del perfil. `armar-reel.cjs`
pega las tres cosas.

**El partido y los números, que son reales.** Gimnasia de Mendoza vs Boca, de
visitante. Tal cual viene: **22 % ganar / 24 % empatar / 55 % perder** — la app
lo dice sin vueltas: "salís de perdedor". Se para atrás: **23 / 27 / 50**, cinco
puntos menos de perder. Se juega la vida: **19 / 18 / 63**, ocho más. Y al
simular de nuevo sin tocar nada: *"Mismos ajustes, mismo resultado."*

**Los planos y qué decir encima** (voz y subtítulos los ponés vos):

| seg | se ve | subtítulo | voz |
|---|---|---|---|
| 0–2,2 | el dado cae sobre la mesa y se frena en el uno | **¿Seguís tirando un dado?** | "¿Seguís tirando un dado?" |
| 2,2–3,4 | el once de Boca en la cancha | | "Este es el partido." |
| 3,4–4,9 | 22 / 24 / 55 · "salís de perdedor" | **Tal cual viene: perdés 55.** | "Tal cual viene, perdés cincuenta y cinco." |
| 4,9–6,6 | toca "Se para atrás", la línea baja a 70 | **Te metés atrás…** | "Me meto atrás." |
| 6,6–8,1 | 23 / 27 / 50 | **…perdés 50.** | "Perdés cincuenta." |
| 8,1–9,7 | toca "Se juega la vida", la línea sube a 95 | **Te la jugás…** | "Me la juego." |
| 9,7–11,3 | 19 / 18 / 63 | **…perdés 63. Vos elegís.** | "Sesenta y tres. Vos elegís el riesgo." |
| 11,3–13,1 | el cartel: "Mismos ajustes, mismo resultado" | **No es un dado.** | "Y si no toco nada, sale lo mismo. Porque no es un dado." |
| 13,1–15,1 | la loseta del 11 | **Armá el 11** · app independiente | "Armá el 11." |

**Si querés rehacerlo con tu club**, los tres pasos, en la carpeta del
proyecto: `node ig/grabar-app.cjs <club>` (graba la app), después
`ffmpeg ... intermedio.mp4` como está anotado en `armar-reel.cjs`, y
`node ig/armar-reel.cjs`. Ojo con una cosa: **los números que salgan son los
que van**. Si con otro club el cambio es de un punto, el reel no sirve y hay
que buscar otro partido, no retocar el número.

**Caption.**
> ¿Seguís tirando un dado? Boca de visitante: perdés 55. Te metés atrás, 50. Te la jugás, 63. Cada decisión mueve el número, y con los mismos ajustes sale siempre lo mismo. 6.000 partidos por simulación, con los goles reales de cada liga. Android en unos días. App independiente, sin relación con ningún club.
> #futbolargentino #ligaprofesional #boca #simulador #armael11

---

## Reel 2 — "Vos contra el DT" (28 segundos)

**La idea.** El formato que se repite todas las fechas. Armás tu once el viernes, sale el del técnico una hora antes del partido, los comparás, y el domingo a la noche el resultado real dice quién tenía razón. Este reel se graba **en tres momentos** de una fecha real: antes, cuando sale el once, y después del partido.

**Qué grabar.** (1) El viernes: armar tu once tocando un jugador (el hueco y el reemplazo), y simular. (2) Cuando llegue el aviso "Salió el once de Talleres" (o cuando aparezca en la app): tocar "Simular el once del DT" y grabar la tarjeta con las dos columnas y la frase "con tu once el modelo te da N puntos más". (3) Después del partido: "Revelar" con el resultado real, la tabla de tres columnas: tu once, el del DT, lo que pasó.

| seg | se ve | texto en pantalla | voz |
|---|---|---|---|
| 0–3 | la cancha con tu once, dedo que toca un jugador y lo cambia | **Viernes. Vos armás el once.** | "Viernes. Yo lo pongo a Depietri de entrada." |
| 3–7 | "Simular". Barra 44 / 27 / 29 | 44 % de ganar | "Simulo. Cuarenta y cuatro." |
| 7–10 | la notificación en el teléfono: "Salió el once de Talleres — El DT puso 4-2-3-1 contra Gimnasia. Simulalo contra el tuyo antes del partido." | **Sábado, 20:00. Salió el once del DT.** | "Sábado, una hora antes. Sale el del técnico. Me avisa." |
| 10–16 | la tarjeta "El once del DT": las dos columnas, los chips de diferencias (Depietri por Navarro), y la frase del modelo | **3 cambios. El modelo me da 6 puntos más.** | "Tres cambios respecto al mío. El modelo dice que el mío gana seis puntos más. Veremos." |
| 16–22 | "Revelar": la tabla de tres: tu once 44 %, el del DT 38 %, y el resultado real 2-1 | **Domingo. Lo que pasó de verdad.** | "Domingo. Dos a uno. Esta vez, tenía razón el técnico." *(o "tenía razón yo" — se dice lo que pasó)* |
| 22–26 | corte rápido: la portada de la app, "La liga argentina es la más imprevisible: está medido" | **La liga más imprevisible de nueve. Está medido.** | "Es la liga más difícil de predecir de las nueve que medimos. Por eso se discute." |
| 26–28 | loseta del 11 | **Armá el 11** · armael11.com · app independiente | "Armá el 11. Todas las fechas." |

**Importante:** el cierre se graba con lo que pasó. Si el resultado le dio la razón al DT, se dice. Es lo que hace creíble al formato: el que solo muestra las veces que acertó, es un tipster.

**Caption.**
> Tu once el viernes. El del DT una hora antes del partido. El resultado real el domingo. Todas las fechas, con todos los clubes de Primera. App independiente, sin relación con ningún club ni con la Liga.
> #futbolargentino #ligaprofesional #[club] #armael11

---

## Cosas para tener a mano en la grabación

- Poné el teléfono en **modo claro** para los reels: el césped y las barras de resultado contrastan mejor con el texto blanco encima.
- Antes de grabar, activá "No molestar" para que no entren notificaciones ajenas. Para el plano de la notificación del reel 2, desactivalo y grabá la pantalla de bloqueo cuando llegue.
- Grabá siempre 5 segundos de más al principio y al final; el editor los necesita.
- Si un número de la simulación cambia entre tomas porque tocaste algo sin querer, **volvé a grabar**; no se edita un número.
- El renglón "publicado …" y la versión que aparecen al pie de la app no molestan, pero si se ven, mejor cortarlos con el encuadre.
