/* Prueba, sin grabar, qué club y qué perilla dan un cambio grande y legible.
   No inventa nada: corre la app de verdad y lee lo que sale en pantalla. */
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const RAIZ = '/home/claude/tste/sitio', PUERTO = 8096;
const TIPOS = { '.html':'text/html', '.js':'text/javascript', '.json':'application/json', '.png':'image/png', '.woff':'font/woff' };
const srv = http.createServer((q, s) => {
  let f = path.join(RAIZ, decodeURIComponent(q.url.split('?')[0].split('#')[0]));
  if (f.endsWith('/')) f += 'index.html';
  if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) { s.writeHead(404); return s.end('no'); }
  s.writeHead(200, { 'content-type': TIPOS[path.extname(f)] || 'text/plain' });
  fs.createReadStream(f).pipe(s);
});
const w = ms => new Promise(r => setTimeout(r, ms));
const leer = pg => pg.evaluate(() => {
  const d = [...document.querySelectorAll('.res div')].map(x => parseFloat(x.textContent));
  const m = (document.querySelector('.marcador') || {}).textContent || '';
  return { win: d[0], draw: d[1], loss: d[2], marcador: m.replace(/\s+/g, ' ').trim() };
});

(async () => {
  await new Promise(r => srv.listen(PUERTO, r));
  const b = await chromium.launch();
  const filas = [];
  for (const club of ['boca', 'river', 'belgrano-cba']) {
    const ctx = await b.newContext({ viewport: { width: 405, height: 900 }, locale: 'es-AR' });
    const pg = await ctx.newPage();
    await pg.route('**/v3.football.api-sports.io/**', r => r.abort());
    await pg.route('**/supabase.co/**', r => r.fulfill({ status: 200, body: '[]', contentType: 'application/json' }));
    await pg.goto(`http://localhost:${PUERTO}/${club}.html`, { waitUntil: 'load' });
    await w(1200);
    await pg.locator('button[data-tab=juego]').click(); await w(800);
    const equipos = await pg.evaluate(() => {
      const f = document.querySelector('.fxp-eq');
      return f ? f.textContent.replace(/\s+/g, ' ').trim() : '';
    });
    await pg.locator('[data-fx]').first().click(); await w(2200);
    await pg.locator('button[data-ver="0"]').click(); await w(300);
    await pg.evaluate(() => document.getElementById('bsim').click()); await w(900);
    const base = await leer(pg);

    /* cada perilla a fondo, de a una, siempre desde cero */
    for (const [k, v] of [['linea', 100], ['linea', -100], ['presion', 100], ['ritmo', 100], ['ancho', 100]]) {
      await pg.evaluate(([k, v]) => {
        const i = document.querySelector(`input[data-k="${k}"]`);
        document.querySelectorAll('input[data-k]').forEach(x => {
          x.value = 0; x.dispatchEvent(new Event('input', { bubbles: true }));
        });
        i.value = v; i.dispatchEvent(new Event('input', { bubbles: true }));
      }, [k, v]);
      await w(400);
      await pg.evaluate(() => document.getElementById('bsim').click()); await w(900);
      const r = await leer(pg);
      filas.push({ club, equipos, k, v, base: `${base.win}/${base.draw}/${base.loss}`,
                   ahora: `${r.win}/${r.draw}/${r.loss}`,
                   dWin: +(r.win - base.win).toFixed(1), dLoss: +(r.loss - base.loss).toFixed(1) });
    }
    await ctx.close();
  }
  await b.close(); srv.close();
  console.log(filas.map(f => `${f.club.padEnd(13)} ${f.k.padEnd(8)} ${String(f.v).padStart(4)}  ${f.base.padEnd(16)} → ${f.ahora.padEnd(16)} ganar ${f.dWin > 0 ? '+' : ''}${f.dWin}  perder ${f.dLoss > 0 ? '+' : ''}${f.dLoss}`).join('\n'));
  console.log('\n' + [...new Set(filas.map(f => f.club + ': ' + f.equipos))].join('\n'));
})();
