/* Graba la app REAL en 1080x1920, modo oscuro, haciendo la secuencia del reel:
     el once → simular (22/24/55) → "se para atrás" → simular (perder 50)
     → "se juega la vida" → simular (perder 63) → simular sin tocar nada.
   Los números no se escriben acá: salen de la app. */
const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const http = require('http'), fs = require('fs'), path = require('path');

const RAIZ = '/home/claude/tste/sitio';
const SALIDA = '/home/claude/tste/ig/grab';
const CLUB = process.argv[2] || 'boca';
const PUERTO = 8095;
const TIPOS = { '.html':'text/html', '.js':'text/javascript', '.json':'application/json',
                '.png':'image/png', '.woff':'font/woff', '.webmanifest':'application/manifest+json' };

const srv = http.createServer((q, s) => {
  let f = path.join(RAIZ, decodeURIComponent(q.url.split('?')[0].split('#')[0]));
  if (f.endsWith('/')) f += 'index.html';
  if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) { s.writeHead(404); return s.end('no'); }
  s.writeHead(200, { 'content-type': TIPOS[path.extname(f)] || 'text/plain' });
  fs.createReadStream(f).pipe(s);
});
const w = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  fs.rmSync(SALIDA, { recursive: true, force: true });
  fs.mkdirSync(SALIDA, { recursive: true });
  await new Promise(r => srv.listen(PUERTO, r));
  const b = await chromium.launch();
  const ctx = await b.newContext({
    /* El video se captura en pixeles CSS, asi que el viewport TIENE que ser
       1080x1920. Para que la app se vea como en un telefono y no como en un
       monitor, se agranda la pagina con zoom: el ancho efectivo queda en 405
       CSS px, que es un telefono. */
    viewport: { width: 1080, height: 1920 }, deviceScaleFactor: 1,
    colorScheme: 'dark', locale: 'es-AR',
    recordVideo: { dir: SALIDA, size: { width: 1080, height: 1920 } },
  });
  const pg = await ctx.newPage();
  const errs = []; pg.on('pageerror', e => errs.push(e.message));
  await pg.route('**/v3.football.api-sports.io/**', r => r.abort());
  await pg.route('**/supabase.co/**', r => r.fulfill({ status: 200, body: '[]', contentType: 'application/json' }));

  const marcas = []; let t0 = 0;
  const marca = n => marcas.push({ n, ms: Date.now() - t0 });
  /* CENTRAR A MANO. Con la pagina ampliada por zoom, scrollIntoView deja el
     elemento fuera de cuadro: las coordenadas que devuelve el navegador y las
     que acepta scrollBy no coinciden. Esto mide, corrige y vuelve a medir
     hasta que queda centrado de verdad; converge en dos vueltas y no depende
     de cuanto valga el zoom. */
  const centrar = async (sel, subir = 0) => {
    for (let i = 0; i < 7; i++) {
      const d = await pg.evaluate(([sel, subir]) => {
        const e = document.querySelector(sel); if (!e) return 0;
        const r = e.getBoundingClientRect();
        const delta = (r.top + r.height / 2) - (innerHeight / 2 - subir);
        scrollBy(0, delta);
        return Math.round(delta);
      }, [sel, subir]);
      if (Math.abs(d) < 6) break;
      await w(120);
    }
    await w(260);
  };
  const aRes = () => centrar('.res', 190);
  /* La fila de planteos se desliza de costado y "Se juega la vida" es el
     quinto: si no se lo trae a la vista, se ve cambiar el resultado sin ver
     que fue lo que se toco. */
  const traerChip = v => pg.evaluate(v => {
    const b = document.querySelector(`button[data-pl="A"][data-plv="${v}"]`);
    const nav = b.closest('nav.filtros');
    nav.scrollLeft = b.offsetLeft - nav.clientWidth / 2 + b.offsetWidth / 2;
  }, v);
  const aPlanteo = () => centrar('nav.filtros [data-pl="A"]', -90);
  const leer = () => pg.evaluate(() =>
    [...document.querySelectorAll('.res div')].map(d => d.textContent.trim()).join(' / '));

  await pg.goto(`http://localhost:${PUERTO}/${CLUB}.html`, { waitUntil: 'load' });
  /* El zoom hace que la app se vea como en un telefono. Y se apaga el
     desplazamiento SUAVE: la app se desplaza sola al terminar de simular, y
     mientras esa animacion corre, cualquier correccion de encuadre se pierde.
     Sin animacion, cada plano queda donde tiene que quedar. */
  await pg.addStyleTag({ content: 'html{zoom:2.667} *{scroll-behavior:auto!important}' });
  await w(1500);
  t0 = Date.now();
  await pg.locator('button[data-tab=juego]').click();
  await w(1200);
  await pg.locator('[data-fx]').first().click();
  await w(2500);
  await pg.locator('button[data-ver="0"]').click();
  await w(500);

  /* ── el once ─────────────────────────────────────────────── */
  await centrar('#campo');
  await w(700);
  marca('once');
  await w(1700);

  /* ── simulación 1: tal cual viene ────────────────────────── */
  await pg.evaluate(() => document.getElementById('bsim').click());
  await w(1100);
  await aRes(); await w(900);
  marca('res1'); const r1 = await leer();
  await w(2600);

  /* ── se para atrás ───────────────────────────────────────── */
  await aPlanteo(); await w(1000);
  await traerChip('atras'); await w(450);
  marca('chip-atras');
  await pg.locator('button[data-pl="A"][data-plv="atras"]').click();
  await w(350);
  await traerChip('atras');   /* al tocar, la app se vuelve a dibujar y la fila
                               de chips vuelve al principio: hay que traerlo
                               de nuevo o no se ve cual quedo encendido */
  await w(950);
  await pg.evaluate(() => document.getElementById('bsim').click());
  await w(1100);
  await aRes(); await w(900);
  marca('res2'); const r2 = await leer();
  await w(2600);

  /* ── se juega la vida ────────────────────────────────────── */
  await aPlanteo(); await w(1000);
  await traerChip('lavida'); await w(450);
  marca('chip-lavida');
  await pg.locator('button[data-pl="A"][data-plv="lavida"]').click();
  await w(350);
  await traerChip('lavida');   /* al tocar, la app se vuelve a dibujar y la fila
                               de chips vuelve al principio: hay que traerlo
                               de nuevo o no se ve cual quedo encendido */
  await w(950);
  await pg.evaluate(() => document.getElementById('bsim').click());
  await w(1100);
  await aRes(); await w(900);
  marca('res3'); const r3 = await leer();
  await w(2600);

  /* ── otra vez, sin tocar nada ────────────────────────────── */
  marca('toca-3');
  await pg.evaluate(() => document.getElementById('bsim').click());
  await w(1300);
  await centrar('.cargando', 60);
  await w(700);
  marca('no-cambiaste');
  const msg = await pg.evaluate(() => (document.querySelector('.cargando') || {}).textContent || '');
  await w(2800);

  await ctx.close(); await b.close(); srv.close();
  const video = fs.readdirSync(SALIDA).find(f => f.endsWith('.webm'));
  fs.writeFileSync(path.join(SALIDA, 'marcas.json'), JSON.stringify({ video, marcas, r1, r2, r3, msg, errs }, null, 1));
  console.log(`video: ${video}\n1: ${r1}\n2: ${r2}\n3: ${r3}\nmsg: ${msg.slice(0, 90)}\nerrs: ${errs.length}`);
  console.log(marcas.map(m => `  ${m.n.padEnd(14)} ${(m.ms / 1000).toFixed(2)}s`).join('\n'));
})();
