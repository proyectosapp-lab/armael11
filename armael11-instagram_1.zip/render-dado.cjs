const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const fs = require('fs');
(async () => {
  fs.rmSync('dadofr', { recursive: true, force: true }); fs.mkdirSync('dadofr');
  const b = await chromium.launch();
  const pg = await b.newPage({ viewport: { width: 1080, height: 1920 } });
  await pg.goto('file:///home/claude/tste/ig/dado.html');
  const N = await pg.evaluate(() => TOTAL);
  for (let i = 0; i < N; i++) {
    await pg.evaluate(i => cuadro(i), i);
    await pg.screenshot({ path: `dadofr/${String(i).padStart(3,'0')}.png` });
  }
  await b.close(); console.log(N + ' cuadros');
})();
